export type Role = 'patient' | 'doctor' | 'admin';

export type AppointmentStatus =
  | 'confirmed'
  | 'pending_payment'
  | 'completed'
  | 'cancelled'
  | 'no_show';

export interface Profile {
  id: string;
  role: Role;
  full_name: string;
  phone: string | null;
  city: string | null;
  gender: 'male' | 'female' | 'other' | null;
  languages: string[];
  created_at: string;
}

export interface Clinic {
  id: string;
  name: string;
  name_ar: string;
  city: string;
  area: string | null;
  address: string | null;
  phone: string | null;
}

export interface WorkingHours {
  [day: string]: string;
}

export interface Doctor {
  id: string;
  user_id: string | null;
  full_name: string;
  specialty: string;
  specialty_ar: string;
  dha_license: string | null;
  dha_verified: boolean;
  consultation_fee: number;
  bio: string;
  gender: 'male' | 'female' | 'other' | null;
  languages: string[];
  city: string | null;
  clinic_id: string | null;
  working_hours: WorkingHours;
  rating: number;
  years_experience: number;
  photo_url: string | null;
  clinic?: Clinic;
}

export interface Appointment {
  id: string;
  booking_ref: string;
  patient_id: string;
  doctor_id: string;
  clinic_id: string | null;
  appointment_date: string;
  start_time: string;
  status: AppointmentStatus;
  fee: number;
  notes: string | null;
  created_at: string;
  doctor?: Doctor;
  patient?: Profile;
  clinic?: Clinic;
}
