import { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CarouselItem {
  image: string;
  alt: string;
  icon: typeof import('lucide-react').Stethoscope;
  title: string;
  titleAr: string;
  description: string;
  descriptionAr: string;
  accentColor: string;
}

interface ServicesCarouselProps {
  items: CarouselItem[];
  lang: 'en' | 'ar';
}

export default function ServicesCarousel({ items, lang }: ServicesCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = 320;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  return (
    <div className="relative">
      {/* Arrows */}
      <div className="mb-4 flex justify-end gap-2">
        <button
          onClick={() => scroll('left')}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-200 bg-white text-text-muted transition-all hover:border-primary-light hover:bg-primary-light hover:text-white dark:border-gray-700 dark:bg-background-dark-card"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-5 w-5 rtl:rotate-180" />
        </button>
        <button
          onClick={() => scroll('right')}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-gray-200 bg-white text-text-muted transition-all hover:border-primary-light hover:bg-primary-light hover:text-white dark:border-gray-700 dark:bg-background-dark-card"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-5 w-5 rtl:rotate-180" />
        </button>
      </div>

      {/* Scrollable row */}
      <div
        ref={scrollRef}
        className="scrollbar-hide flex gap-5 overflow-x-auto scroll-smooth pb-2"
      >
        {items.map((item, i) => {
          const Icon = item.icon;
          return (
            <div
              key={i}
              className="group relative w-[280px] shrink-0 cursor-pointer"
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              <div className="card overflow-hidden transition-all duration-500 group-hover:-translate-y-2 group-hover:shadow-xl">
                {/* Image with overlay */}
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.alt}
                    className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                    loading="lazy"
                  />
                  <div
                    className="absolute inset-0 transition-opacity duration-500"
                    style={{
                      background: `linear-gradient(to top, ${item.accentColor}99, transparent 60%)`,
                      opacity: hoveredIndex === i ? 0.9 : 0.5,
                    }}
                  />
                  {/* Floating icon */}
                  <div
                    className="absolute -bottom-5 left-5 flex h-12 w-12 items-center justify-center rounded-xl shadow-lg transition-all duration-500 group-hover:scale-110"
                    style={{ backgroundColor: item.accentColor }}
                  >
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-5 pt-7">
                  <h3 className="font-semibold text-text-main dark:text-text-dark">
                    {lang === 'ar' ? item.titleAr : item.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-text-muted dark:text-text-dark-muted">
                    {lang === 'ar' ? item.descriptionAr : item.description}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
