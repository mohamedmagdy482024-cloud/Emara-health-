import { Link, useNavigate } from 'react-router-dom';
import { Globe, LogOut, Menu, X, Moon, Sun } from 'lucide-react';
import { useState } from 'react';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import { useTheme } from '../lib/theme';
import Logo from './Logo';

export default function Header() {
  const { t, lang, setLang } = useI18n();
  const { session, profile, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const navLinkClass =
    'text-sm font-medium text-text-muted hover:text-primary transition-colors dark:text-text-dark-muted dark:hover:text-primary-light';

  const dashboardLink =
    profile?.role === 'doctor'
      ? '/doctor'
      : profile?.role === 'admin'
        ? '/admin'
        : '/dashboard';

  return (
    <header className="sticky top-0 z-50 border-b border-gray-100 bg-white/90 backdrop-blur-md transition-colors dark:border-gray-800 dark:bg-background-dark/90">
      <div className="container-wide flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/">
          <Logo size="md" />
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link to="/" className={navLinkClass}>
            {t('nav.home')}
          </Link>
          <Link to="/doctors" className={navLinkClass}>
            {t('nav.doctors')}
          </Link>
          {session && profile && (
            <Link to={dashboardLink} className={navLinkClass}>
              {profile.role === 'doctor'
                ? t('nav.doctorPortal')
                : profile.role === 'admin'
                  ? t('nav.adminPanel')
                  : t('nav.dashboard')}
            </Link>
          )}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <button
            onClick={toggleTheme}
            className="btn-ghost"
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
          </button>

          <button
            onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
            className="btn-ghost"
            aria-label="Toggle language"
          >
            <Globe className="h-4 w-4" />
            {lang === 'en' ? 'العربية' : 'English'}
          </button>

          {session ? (
            <button onClick={handleSignOut} className="btn-ghost">
              <LogOut className="h-4 w-4" />
              {t('nav.signOut')}
            </button>
          ) : (
            <>
              <Link to="/signin" className="btn-ghost">
                {t('nav.signIn')}
              </Link>
              <Link to="/register" className="btn-accent">
                {t('nav.register')}
              </Link>
            </>
          )}
        </div>

        <button
          onClick={() => setMobileOpen(!mobileOpen)}
          className="rounded-lg p-2 text-text-muted hover:bg-gray-100 dark:hover:bg-background-dark-elevated md:hidden"
          aria-label="Menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <nav className="animate-slide-down border-t border-gray-100 bg-white px-4 py-4 dark:border-gray-800 dark:bg-background-dark md:hidden">
          <div className="flex flex-col gap-3">
            <Link to="/" className={navLinkClass} onClick={() => setMobileOpen(false)}>
              {t('nav.home')}
            </Link>
            <Link to="/doctors" className={navLinkClass} onClick={() => setMobileOpen(false)}>
              {t('nav.doctors')}
            </Link>
            {session && profile && (
              <Link
                to={dashboardLink}
                className={navLinkClass}
                onClick={() => setMobileOpen(false)}
              >
                {profile.role === 'doctor'
                  ? t('nav.doctorPortal')
                  : profile.role === 'admin'
                    ? t('nav.adminPanel')
                    : t('nav.dashboard')}
              </Link>
            )}
            <div className="flex gap-2 pt-2">
              <button onClick={toggleTheme} className="btn-ghost flex-1">
                {theme === 'light' ? <Moon className="h-4 w-4" /> : <Sun className="h-4 w-4" />}
                {theme === 'light' ? 'Dark' : 'Light'}
              </button>
              <button
                onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
                className="btn-ghost flex-1"
              >
                <Globe className="h-4 w-4" />
                {lang === 'en' ? 'العربية' : 'English'}
              </button>
            </div>
            {session ? (
              <button onClick={handleSignOut} className="btn-ghost justify-start">
                <LogOut className="h-4 w-4" />
                {t('nav.signOut')}
              </button>
            ) : (
              <div className="flex gap-2">
                <Link to="/signin" className="btn-secondary flex-1" onClick={() => setMobileOpen(false)}>
                  {t('nav.signIn')}
                </Link>
                <Link to="/register" className="btn-accent flex-1" onClick={() => setMobileOpen(false)}>
                  {t('nav.register')}
                </Link>
              </div>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}
