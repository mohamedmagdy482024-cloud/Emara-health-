import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import Logo from './Logo';

export default function Footer() {
  const { t } = useI18n();

  return (
    <footer className="mt-auto border-t border-gray-800 bg-background-dark text-gray-300">
      <div className="container-wide px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <div className="md:col-span-1">
            <Logo size="md" className="[&_span]:text-white" />
            <p className="mt-4 text-sm leading-relaxed text-gray-400">{t('footer.aboutText')}</p>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              {t('footer.quickLinks')}
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <Link to="/" className="text-gray-400 transition-colors hover:text-primary-light">
                  {t('nav.home')}
                </Link>
              </li>
              <li>
                <Link to="/doctors" className="text-gray-400 transition-colors hover:text-primary-light">
                  {t('nav.doctors')}
                </Link>
              </li>
              <li>
                <Link to="/signin" className="text-gray-400 transition-colors hover:text-primary-light">
                  {t('nav.signIn')}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              {t('footer.contact')}
            </h3>
            <ul className="mt-4 space-y-3 text-sm text-gray-400">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary-light" />
                +971 4 123 4500
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-primary-light" />
                care@emarahealth.ae
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-primary-light" />
                Dubai Marina, UAE
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">Legal</h3>
            <ul className="mt-4 space-y-2 text-sm">
              <li>
                <span className="text-gray-400">
                  {t('footer.privacy')}{' '}
                  <span className="text-xs italic text-gray-500">({t('footer.draft')})</span>
                </span>
              </li>
              <li>
                <span className="text-gray-400">
                  {t('footer.terms')}{' '}
                  <span className="text-xs italic text-gray-500">({t('footer.draft')})</span>
                </span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-8 border-t border-gray-800 pt-6 text-center text-sm text-gray-500">
          © {new Date().getFullYear()} Emara Health Platform. {t('footer.rights')}
        </div>
      </div>
    </footer>
  );
}
