import { useCountUp } from '../lib/hooks';

interface AnimatedCounterProps {
  value: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
  className?: string;
}

export default function AnimatedCounter({
  value,
  suffix = '',
  prefix = '',
  duration = 2000,
  className = '',
}: AnimatedCounterProps) {
  const count = useCountUp(value, duration, true);

  return (
    <span className={className}>
      {prefix}{count}{suffix}
    </span>
  );
}
