import { getInitials, getAvatarColor } from '../lib/utils';

interface DoctorAvatarProps {
  name: string;
  size?: 'sm' | 'md' | 'lg';
  photoUrl?: string | null;
}

const sizeClasses = {
  sm: 'h-10 w-10 text-sm',
  md: 'h-14 w-14 text-lg',
  lg: 'h-20 w-20 text-2xl',
};

export default function DoctorAvatar({ name, size = 'md', photoUrl }: DoctorAvatarProps) {
  if (photoUrl) {
    return (
      <img
        src={photoUrl}
        alt={name}
        className={`${sizeClasses[size]} rounded-full object-cover ring-2 ring-primary-light/20`}
      />
    );
  }

  return (
    <div
      className={`${sizeClasses[size]} ${getAvatarColor(
        name,
      )} flex items-center justify-center rounded-full font-semibold text-white ring-2 ring-primary-light/20`}
    >
      {getInitials(name)}
    </div>
  );
}
