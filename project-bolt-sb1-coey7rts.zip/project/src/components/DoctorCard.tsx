import { Link } from 'react-router-dom';
import { BadgeCheck, Star, MapPin } from 'lucide-react';
import type { Doctor } from '../lib/types';
import { useI18n } from '../lib/i18n';
import { formatAED } from '../lib/utils';
import DoctorAvatar from './DoctorAvatar';

interface DoctorCardProps {
  doctor: Doctor;
}

export default function DoctorCard({ doctor }: DoctorCardProps) {
  const { t, lang } = useI18n();

  return (
    <Link
      to={`/doctors/${doctor.id}`}
      className="card group relative block overflow-hidden p-5 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-xl dark:hover:border-primary-light/30"
    >
      <div className="flex items-start gap-4">
        <DoctorAvatar name={doctor.full_name} photoUrl={doctor.photo_url} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <h3 className="truncate font-semibold text-text-main dark:text-text-dark" dir="auto">
              {doctor.full_name}
            </h3>
            {doctor.dha_verified && (
              <BadgeCheck className="h-4 w-4 shrink-0 text-primary-light" />
            )}
          </div>
          <p className="mt-0.5 text-sm text-primary dark:text-primary-light">
            {lang === 'ar' && doctor.specialty_ar ? doctor.specialty_ar : doctor.specialty}
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-text-muted dark:text-text-dark-muted">
            {doctor.city && (
              <span className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {doctor.city}
              </span>
            )}
            <span className="flex items-center gap-1">
              <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
              {doctor.rating.toFixed(1)}
            </span>
            <span>{doctor.years_experience} {t('doctor.experience')}</span>
          </div>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-gray-50 pt-4 dark:border-gray-800">
        <div>
          <p className="text-xs text-text-muted dark:text-text-dark-muted">{t('doctor.consultationFee')}</p>
          <p className="font-semibold text-text-main dark:text-text-dark">{formatAED(doctor.consultation_fee)}</p>
        </div>
        <span className="rounded-lg bg-primary-light/10 px-4 py-2 text-sm font-medium text-primary-light transition-all duration-300 group-hover:bg-primary-light group-hover:text-white group-hover:shadow-md">
          {t('doctor.viewProfile')}
        </span>
      </div>
    </Link>
  );
}
