import { type ReactNode, type ElementType } from 'react';
import { useScrollReveal } from '../lib/hooks';

interface RevealProps {
  children: ReactNode;
  animation?: 'up' | 'scale' | 'left' | 'right';
  delay?: 1 | 2 | 3 | 4 | 5 | 6;
  as?: ElementType;
  className?: string;
}

export default function Reveal({
  children,
  animation = 'up',
  delay,
  as: Tag = 'div',
  className = '',
}: RevealProps) {
  const { ref, visible } = useScrollReveal<HTMLElement>();

  const animationClass =
    animation === 'scale'
      ? 'reveal-scale'
      : animation === 'left'
        ? 'reveal-left'
        : animation === 'right'
          ? 'reveal-right'
          : 'reveal';

  const delayClass = delay ? `stagger-${delay}` : '';

  return (
    <Tag
      ref={ref as never}
      className={`${animationClass} ${delayClass} ${visible ? 'reveal-visible' : ''} ${className}`}
    >
      {children}
    </Tag>
  );
}
