interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

const iconSizes = {
  sm: 28,
  md: 36,
  lg: 48,
};

const textSizes = {
  sm: 'text-base',
  md: 'text-lg',
  lg: 'text-2xl',
};

export default function Logo({ size = 'md', showText = true, className = '' }: LogoProps) {
  const iconSize = iconSizes[size];

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div
        className="flex items-center justify-center rounded-xl bg-primary shadow-sm"
        style={{ width: iconSize + 8, height: iconSize + 8 }}
      >
        <svg
          width={iconSize}
          height={iconSize}
          viewBox="0 0 36 36"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Network/connection nodes */}
          <circle cx="6" cy="10" r="1.8" fill="white" opacity="0.5" />
          <circle cx="6" cy="26" r="1.8" fill="white" opacity="0.5" />
          <circle cx="30" cy="18" r="2.2" fill="white" opacity="0.4" />
          <line x1="6" y1="10" x2="14" y2="18" stroke="white" strokeWidth="1" opacity="0.25" />
          <line x1="6" y1="26" x2="14" y2="18" stroke="white" strokeWidth="1" opacity="0.25" />
          <line x1="22" y1="18" x2="30" y2="18" stroke="white" strokeWidth="1" opacity="0.2" />

          {/* Heartbeat/pulse line */}
          <path
            d="M3 18 L10 18 L12 12 L15 24 L18 14 L21 22 L24 18 L33 18"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </svg>
      </div>
      {showText && (
        <span className={`${textSizes[size]} font-bold text-text-main dark:text-text-dark`}>
          Emara<span className="text-primary-light"> Health</span>
        </span>
      )}
    </div>
  );
}
