import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Calendar, Clock, MapPin, X, CheckCircle2, XCircle,
  AlertCircle, CalendarPlus, User,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import type { Appointment, AppointmentStatus } from '../lib/types';
import { formatAED, formatDate, formatTime } from '../lib/utils';
import DoctorAvatar from '../components/DoctorAvatar';

const statusConfig: Record<AppointmentStatus, { color: string; label: string; labelAr: string; icon: typeof CheckCircle2 }> = {
  confirmed: { color: 'bg-success/20 text-success', label: 'Confirmed', labelAr: 'مؤكد', icon: CheckCircle2 },
  pending_payment: { color: 'bg-warning/20 text-warning', label: 'Pending Payment', labelAr: 'بانتظار الدفع', icon: AlertCircle },
  completed: { color: 'bg-blue-100 text-blue-700', label: 'Completed', labelAr: 'مكتمل', icon: CheckCircle2 },
  cancelled: { color: 'bg-gray-100 dark:bg-background-dark-elevated text-text-muted dark:text-text-dark-muted', label: 'Cancelled', labelAr: 'ملغي', icon: XCircle },
  no_show: { color: 'bg-error/20 text-error', label: 'No Show', labelAr: 'لم يحضر', icon: XCircle },
};

export default function DashboardPage() {
  const { t, lang } = useI18n();
  const { session, profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'upcoming' | 'past'>('upcoming');
  const [cancelTarget, setCancelTarget] = useState<Appointment | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [cancelMessage, setCancelMessage] = useState<string | null>(null);

  useEffect(() => {
    if (authLoading) return;
    if (!session) {
      navigate('/signin');
      return;
    }
    if (profile && profile.role !== 'patient') {
      navigate(profile.role === 'doctor' ? '/doctor' : '/admin');
      return;
    }

    const fetchAppointments = async () => {
      if (!session) return;
      const { data, error } = await supabase
        .from('appointments')
        .select('*, doctor:doctors(*, clinic:clinics(*))')
        .eq('patient_id', session.user.id)
        .order('appointment_date', { ascending: false })
        .order('start_time', { ascending: false });

      if (error) {
        console.error('Error fetching appointments:', error);
      } else {
        setAppointments(data as Appointment[]);
      }
      setLoading(false);
    };
    fetchAppointments();
  }, [session, profile, authLoading, navigate]);

  const getRefundTier = (appointment: Appointment): 'full' | 'half' | 'none' => {
    const apptDateTime = new Date(`${appointment.appointment_date}T${appointment.start_time}`);
    const now = new Date();
    const hoursDiff = (apptDateTime.getTime() - now.getTime()) / (1000 * 60 * 60);
    if (hoursDiff > 24) return 'full';
    if (hoursDiff > 4) return 'half';
    return 'none';
  };

  const handleCancel = async () => {
    if (!cancelTarget) return;
    setCancelling(true);

    const { error } = await supabase
      .from('appointments')
      .update({ status: 'cancelled' })
      .eq('id', cancelTarget.id);

    if (error) {
      setCancelMessage(t('common.error'));
    } else {
      setAppointments((prev) =>
        prev.map((a) => (a.id === cancelTarget.id ? { ...a, status: 'cancelled' as AppointmentStatus } : a)),
      );
      setCancelMessage(t('dashboard.cancelled'));
    }

    setCancelling(false);
    setTimeout(() => {
      setCancelTarget(null);
      setCancelMessage(null);
    }, 2000);
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-text-muted dark:text-text-dark-muted">{t('common.loading')}</p>
      </div>
    );
  }

  const now = new Date();
  const upcoming = appointments
    .filter((a) => {
      const apptDate = new Date(`${a.appointment_date}T${a.start_time}`);
      return apptDate >= now && a.status !== 'cancelled' && a.status !== 'completed' && a.status !== 'no_show';
    })
    .sort((a, b) => {
      const da = new Date(`${a.appointment_date}T${a.start_time}`).getTime();
      const db = new Date(`${b.appointment_date}T${b.start_time}`).getTime();
      return da - db;
    });

  const past = appointments
    .filter((a) => {
      const apptDate = new Date(`${a.appointment_date}T${a.start_time}`);
      return apptDate < now || a.status === 'cancelled' || a.status === 'completed' || a.status === 'no_show';
    })
    .sort((a, b) => {
      const da = new Date(`${a.appointment_date}T${a.start_time}`).getTime();
      const db = new Date(`${b.appointment_date}T${b.start_time}`).getTime();
      return db - da;
    });

  const nextAppointment = upcoming[0];
  const displayList = activeTab === 'upcoming' ? upcoming : past;

  return (
    <div className="section-padding bg-background dark:bg-background-dark">
      <div className="container-wide">
        {/* Welcome header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-main dark:text-text-dark">{t('dashboard.title')}</h1>
          <p className="mt-1 text-text-muted dark:text-text-dark-muted">
            {t('dashboard.welcome')}, <span className="font-medium text-text-main dark:text-text-dark">{profile?.full_name}</span>
          </p>
        </div>

        {/* Next appointment highlight */}
        {nextAppointment && (
          <div className="mb-8 overflow-hidden rounded-2xl bg-gradient-to-br from-primary to-primary-700 p-6 text-white shadow-lg sm:p-8">
            <p className="text-sm font-medium text-primary-light-100">{t('dashboard.nextAppointment')}</p>
            <div className="mt-4 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4">
                {nextAppointment.doctor && (
                  <DoctorAvatar name={nextAppointment.doctor.full_name} photoUrl={nextAppointment.doctor.photo_url} />
                )}
                <div>
                  <p className="text-lg font-bold" dir="auto">
                    {nextAppointment.doctor?.full_name}
                  </p>
                  <p className="text-sm text-primary-light-100">
                    {lang === 'ar' && nextAppointment.doctor?.specialty_ar
                      ? nextAppointment.doctor.specialty_ar
                      : nextAppointment.doctor?.specialty}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-sm text-primary-light-100">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {formatDate(nextAppointment.appointment_date, lang)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {formatTime(nextAppointment.start_time)}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-start gap-2 sm:items-end">
                <span className="badge bg-white/20 text-white">
                  {lang === 'ar' ? statusConfig[nextAppointment.status].labelAr : statusConfig[nextAppointment.status].label}
                </span>
                <span className="font-mono text-sm text-primary-light-100">{nextAppointment.booking_ref}</span>
                <span className="text-lg font-bold">{formatAED(nextAppointment.fee)}</span>
              </div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="mb-6 flex gap-1 rounded-xl bg-gray-100 dark:bg-background-dark-elevated p-1">
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`flex-1 rounded-lg py-2.5 text-sm font-medium transition-all ${
              activeTab === 'upcoming' ? 'bg-white dark:bg-background-dark-card text-primary dark:text-primary-light shadow-sm' : 'text-text-muted dark:text-text-dark-muted'
            }`}
          >
            {t('dashboard.upcoming')} ({upcoming.length})
          </button>
          <button
            onClick={() => setActiveTab('past')}
            className={`flex-1 rounded-lg py-2.5 text-sm font-medium transition-all ${
              activeTab === 'past' ? 'bg-white dark:bg-background-dark-card text-primary dark:text-primary-light shadow-sm' : 'text-text-muted dark:text-text-dark-muted'
            }`}
          >
            {t('dashboard.past')} ({past.length})
          </button>
        </div>

        {/* Appointments list */}
        {displayList.length === 0 ? (
          <div className="card flex flex-col items-center justify-center p-12 text-center">
            {activeTab === 'upcoming' ? (
              <>
                <CalendarPlus className="h-12 w-12 text-text-muted dark:text-text-dark-muted" />
                <p className="mt-4 text-text-muted dark:text-text-dark-muted">{t('dashboard.noUpcoming')}</p>
                <Link to="/doctors" className="btn-primary mt-4">
                  {t('dashboard.bookNow')}
                </Link>
              </>
            ) : (
              <>
                <Calendar className="h-12 w-12 text-text-muted dark:text-text-dark-muted" />
                <p className="mt-4 text-text-muted dark:text-text-dark-muted">{t('dashboard.noAppointments')}</p>
              </>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {displayList.map((appt) => {
              const status = statusConfig[appt.status];
              const StatusIcon = status.icon;
              const canCancel = appt.status === 'confirmed' || appt.status === 'pending_payment';

              return (
                <div key={appt.id} className="card p-5">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-center gap-4">
                      {appt.doctor && (
                        <DoctorAvatar name={appt.doctor.full_name} photoUrl={appt.doctor.photo_url} size="sm" />
                      )}
                      <div>
                        <p className="font-semibold text-text-main dark:text-text-dark" dir="auto">
                          {appt.doctor?.full_name}
                        </p>
                        <p className="text-sm text-text-muted dark:text-text-dark-muted">
                          {lang === 'ar' && appt.doctor?.specialty_ar ? appt.doctor.specialty_ar : appt.doctor?.specialty}
                        </p>
                        <div className="mt-1.5 flex flex-wrap gap-x-4 gap-y-1 text-xs text-text-muted dark:text-text-dark-muted">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {formatDate(appt.appointment_date, lang)}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-3.5 w-3.5" />
                            {formatTime(appt.start_time)}
                          </span>
                          {appt.doctor?.city && (
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3.5 w-3.5" />
                              {appt.doctor.city}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="text-end">
                        <span className={`badge ${status.color}`}>
                          <StatusIcon className="h-3.5 w-3.5" />
                          {lang === 'ar' ? status.labelAr : status.label}
                        </span>
                        <p className="mt-1.5 font-semibold text-text-main dark:text-text-dark">{formatAED(appt.fee)}</p>
                        <p className="font-mono text-xs text-text-muted dark:text-text-dark-muted">{appt.booking_ref}</p>
                      </div>

                      {canCancel && activeTab === 'upcoming' && (
                        <button
                          onClick={() => setCancelTarget(appt)}
                          className="rounded-lg border border-error/30 px-3 py-2 text-sm font-medium text-error transition-colors hover:bg-error/10"
                        >
                          {t('dashboard.cancel')}
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Cancel modal */}
      {cancelTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => !cancelling && setCancelTarget(null)} />
          <div className="relative w-full max-w-md animate-slide-up rounded-2xl bg-white dark:bg-background-dark-card p-6 shadow-xl">
            {cancelMessage ? (
              <div className="text-center">
                <CheckCircle2 className="mx-auto h-12 w-12 text-success" />
                <p className="mt-4 text-lg font-semibold text-text-main dark:text-text-dark">{cancelMessage}</p>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-error/20">
                    <X className="h-5 w-5 text-error" />
                  </div>
                  <h2 className="text-lg font-bold text-text-main dark:text-text-dark">{t('dashboard.cancelTitle')}</h2>
                </div>

                <div className="mt-4 rounded-xl bg-gray-50 dark:bg-background-dark-card p-4">
                  <p className="text-sm text-text-main dark:text-text-dark" dir="auto">
                    {cancelTarget.doctor?.full_name}
                  </p>
                  <p className="mt-1 text-xs text-text-muted dark:text-text-dark-muted">
                    {formatDate(cancelTarget.appointment_date, lang)} • {formatTime(cancelTarget.start_time)}
                  </p>
                </div>

                <p className="mt-4 text-sm text-text-muted dark:text-text-dark-muted">{t('dashboard.cancelConfirm')}</p>

                {(() => {
                  const tier = getRefundTier(cancelTarget);
                  const refundText =
                    tier === 'full'
                      ? t('dashboard.refundFull')
                      : tier === 'half'
                        ? t('dashboard.refundHalf')
                        : t('dashboard.refundNone');
                  const refundColor =
                    tier === 'full'
                      ? 'bg-success/10 text-success'
                      : tier === 'half'
                        ? 'bg-warning/10 text-warning'
                        : 'bg-error/10 text-error';

                  return (
                    <div className={`mt-3 rounded-xl px-4 py-3 text-sm ${refundColor}`}>{refundText}</div>
                  );
                })()}

                <div className="mt-6 flex gap-3">
                  <button
                    onClick={() => setCancelTarget(null)}
                    disabled={cancelling}
                    className="btn-secondary flex-1"
                  >
                    {t('common.close')}
                  </button>
                  <button
                    onClick={handleCancel}
                    disabled={cancelling}
                    className="flex-1 rounded-xl bg-error px-6 py-3 text-sm font-semibold text-white transition-all hover:bg-error-600 disabled:opacity-50"
                  >
                    {cancelling ? t('common.loading') : t('dashboard.cancel')}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
