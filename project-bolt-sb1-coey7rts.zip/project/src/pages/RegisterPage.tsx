import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, User, Phone, MapPin, AlertCircle } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import Logo from '../components/Logo';

export default function RegisterPage() {
  const { t } = useI18n();
  const { signUp } = useAuth();
  const navigate = useNavigate();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [city, setCity] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);

    const { error: signUpError } = await signUp(email.trim(), password, fullName.trim(), phone.trim(), city.trim());

    if (signUpError) {
      setError(signUpError.includes('already') ? t('auth.emailExists') : signUpError);
      setLoading(false);
      return;
    }

    navigate('/dashboard');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary-light/10 via-background to-primary/10 dark:from-primary/20 dark:via-background-dark dark:to-primary/20 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link to="/" className="inline-flex items-center gap-2">
            <Logo />
          </Link>
        </div>

        <div className="card p-8">
          <h1 className="text-2xl font-bold text-text-main dark:text-text-dark">{t('auth.register')}</h1>
          <p className="mt-2 text-sm text-text-muted dark:text-text-dark-muted">{t('auth.registerSubtitle')}</p>

          {error && (
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-error/10 px-4 py-3 text-sm text-error">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                {t('auth.fullName')}
              </label>
              <div className="relative">
                <User className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="input-field ps-10"
                  placeholder="Ahmed Al Mansouri"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                {t('auth.emailOrPhone')}
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="input-field ps-10"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                  {t('auth.phone')}
                </label>
                <div className="relative">
                  <Phone className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="input-field ps-10"
                    placeholder="+971 50 123 4567"
                  />
                </div>
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                  {t('auth.city')}
                </label>
                <div className="relative">
                  <MapPin className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="input-field ps-10"
                    placeholder="Dubai"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                {t('auth.password')}
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="input-field ps-10"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? t('common.loading') : t('auth.registerBtn')}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-text-muted dark:text-text-dark-muted">
            {t('auth.haveAccount')}{' '}
            <Link to="/signin" className="font-medium text-primary dark:text-primary-light hover:text-primary-600 dark:hover:text-primary-light">
              {t('auth.signInHere')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
