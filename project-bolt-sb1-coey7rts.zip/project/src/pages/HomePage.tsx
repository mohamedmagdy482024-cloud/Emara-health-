import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Search, Heart, Brain, Bone, Eye, Baby, Stethoscope, Activity,
  Users, Building2, Award, ArrowRight, Shield, Pill, CalendarCheck,
  Clock, MapPin, Star, Phone, Sparkles, TrendingUp,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import type { Doctor } from '../lib/types';
import DoctorCard from '../components/DoctorCard';
import HeroGallery from '../components/HeroGallery';
import ServicesCarousel from '../components/ServicesCarousel';
import Reveal from '../components/Reveal';
import AnimatedCounter from '../components/AnimatedCounter';
import { useScrollReveal } from '../lib/hooks';
import { formatAED } from '../lib/utils';

const heroImages = [
  { url: 'https://images.pexels.com/photos/5214992/pexels-photo-5214992.jpeg?auto=compress&cs=tinysrgb&w=1600', alt: 'Doctor examining patient' },
  { url: 'https://images.pexels.com/photos/8460125/pexels-photo-8460125.jpeg?auto=compress&cs=tinysrgb&w=1600', alt: 'Doctor checking vitals' },
  { url: 'https://images.pexels.com/photos/7579823/pexels-photo-7579823.jpeg?auto=compress&cs=tinysrgb&w=1600', alt: 'Female doctor consulting patient' },
  { url: 'https://images.pexels.com/photos/7108324/pexels-photo-7108324.jpeg?auto=compress&cs=tinysrgb&w=1600', alt: 'Modern clinic interior' },
  { url: 'https://images.pexels.com/photos/19957214/pexels-photo-19957214.jpeg?auto=compress&cs=tinysrgb&w=1600', alt: 'Telehealth consultation' },
];

const serviceItems = [
  {
    image: 'https://images.pexels.com/photos/6129444/pexels-photo-6129444.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Doctor consultation',
    icon: Stethoscope,
    title: 'Doctor Consultations',
    titleAr: 'استشارات الأطباء',
    description: 'Book appointments with verified doctors across all specialties',
    descriptionAr: 'احجز مواعيد مع أطباء موثقين في جميع التخصصات',
    accentColor: '#0F4C81',
  },
  {
    image: 'https://images.pexels.com/photos/3873149/pexels-photo-3873149.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Pharmacy',
    icon: Pill,
    title: 'Pharmacy & Medications',
    titleAr: 'الصيدلية والأدوية',
    description: 'WhatsApp medication reminders and prescription refills',
    descriptionAr: 'تذكيرات الأدوية عبر واتساب وإعادة ملء الوصفات',
    accentColor: '#059669',
  },
  {
    image: 'https://images.pexels.com/photos/8460084/pexels-photo-8460084.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Health checkup',
    icon: Heart,
    title: 'Health Checkups',
    titleAr: 'الفحوصات الصحية',
    description: 'Comprehensive full-body checkups across the UAE',
    descriptionAr: 'فحوصات شاملة للجسم في جميع أنحاء الإمارات',
    accentColor: '#0EA5E9',
  },
  {
    image: 'https://images.pexels.com/photos/5452247/pexels-photo-5452247.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Medical team',
    icon: Building2,
    title: 'Clinics & Centers',
    titleAr: 'العيادات والمراكز',
    description: 'Network of accredited clinics across the Emirates',
    descriptionAr: 'شبكة عيادات معتمدة في جميع أنحاء الإمارات',
    accentColor: '#0F4C81',
  },
  {
    image: 'https://images.pexels.com/photos/7195117/pexels-photo-7195117.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Telemedicine',
    icon: Activity,
    title: 'Telemedicine',
    titleAr: 'الطب عن بعد',
    description: 'Remote consultations with specialists via video calls',
    descriptionAr: 'استشارات عن بعد مع المتخصصين عبر مكالمات الفيديو',
    accentColor: '#0EA5E9',
  },
  {
    image: 'https://images.pexels.com/photos/7108399/pexels-photo-7108399.jpeg?auto=compress&cs=tinysrgb&w=600',
    alt: 'Medical facility',
    icon: Shield,
    title: 'Diagnostic Services',
    titleAr: 'الخدمات التشخيصية',
    description: 'Lab tests, imaging, and diagnostics with quick results',
    descriptionAr: 'تحاليل مخبرية وأشعة وتشخيصات بنتائج سريعة',
    accentColor: '#059669',
  },
];

const testimonials = [
  {
    name: 'Ahmed Al Mansouri',
    role: 'Patient — Dubai',
    roleAr: 'مريض — دبي',
    text: 'I booked a cardiology appointment in under 2 minutes. The whole experience was smooth, professional, and the doctor was excellent. Emara Health made healthcare simple.',
    textAr: 'حجزت موعد أمراض القلب في أقل من دقيقتين. التجربة كانت سلسة ومهنية والطبيب كان ممتازاً. جعلت الإمارة للصحة الرعاية الصحية بسيطة.',
    rating: 5,
  },
  {
    name: 'Dr. Fatima Al Zahra',
    role: 'Dermatologist — Dubai',
    roleAr: 'طبيبة جلدية — دبي',
    text: 'As a doctor, the portal saves me hours every day. I can see my schedule, mark patients as complete, and manage my working hours all in one place.',
    textAr: 'كطبيبة، توفر لي البوابة ساعات كل يوم. أستطيع رؤية جدولي وتأكيد إكمال المرضى وإدارة ساعات عملي في مكان واحد.',
    rating: 5,
  },
  {
    name: 'Salem Al Otaibi',
    role: 'Patient — Abu Dhabi',
    roleAr: 'مريض — أبوظبي',
    text: 'The Arabic support is fantastic. Everything from booking to the dashboard works perfectly in Arabic. This is how healthcare should be in the UAE.',
    textAr: 'دعم العربية رائع. كل شيء من الحجز إلى لوحة التحكم يعمل بشكل مثالي بالعربية. هكذا يجب أن تكون الرعاية الصحية في الإمارات.',
    rating: 5,
  },
];

export default function HomePage() {
  const { t, lang } = useI18n();
  const navigate = useNavigate();
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [stats, setStats] = useState({ doctors: 0, specialties: 0, clinics: 0 });
  const [searchValue, setSearchValue] = useState('');
  const [loading, setLoading] = useState(true);
  const { ref: statsRef, visible: statsVisible } = useScrollReveal<HTMLDivElement>();

  useEffect(() => {
    const fetchData = async () => {
      const [{ data: doctorData }, { count: doctorCount }, { count: clinicCount }] = await Promise.all([
        supabase
          .from('doctors')
          .select('*, clinic:clinics(*)')
          .order('rating', { ascending: false })
          .limit(6),
        supabase.from('doctors').select('*', { count: 'exact', head: true }),
        supabase.from('clinics').select('*', { count: 'exact', head: true }),
      ]);

      if (doctorData) setDoctors(doctorData as Doctor[]);
      setStats({
        doctors: doctorCount ?? 0,
        specialties: new Set(doctorData?.map((d) => d.specialty)).size,
        clinics: clinicCount ?? 0,
      });
      setLoading(false);
    };
    fetchData();
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchValue.trim()) params.set('q', searchValue.trim());
    navigate(`/doctors?${params.toString()}`);
  };

  const specialties = [
    { name: 'Cardiology', nameAr: 'أمراض القلب', icon: Heart },
    { name: 'Dermatology', nameAr: 'الأمراض الجلدية', icon: Activity },
    { name: 'Orthopedics', nameAr: 'جراحة العظام', icon: Bone },
    { name: 'Pediatrics', nameAr: 'طب الأطفال', icon: Baby },
    { name: 'Neurology', nameAr: 'الأعصاب', icon: Brain },
    { name: 'Ophthalmology', nameAr: 'طب العيون', icon: Eye },
  ];

  const statItems = [
    { icon: Users, value: stats.doctors, suffix: '', label: t('stats.doctors'), color: 'text-primary-light' },
    { icon: Stethoscope, value: stats.specialties, suffix: '+', label: t('stats.specialties'), color: 'text-primary' },
    { icon: Building2, value: stats.clinics, suffix: '', label: t('stats.clinics'), color: 'text-success' },
    { icon: Award, value: 10, suffix: 'K+', label: t('stats.patients'), color: 'text-primary-light' },
  ];

  const trustItems = [
    {
      icon: Shield,
      title: lang === 'ar' ? 'موثق وآمن' : 'Verified & Secure',
      desc: lang === 'ar'
        ? 'جميع الأطباء موثقون من دائرة الصحة. بياناتك محمية بأعلى معايير الأمان.'
        : 'All doctors are DHA-verified. Your data is protected with the highest security standards.',
      color: 'text-primary',
      bgColor: 'bg-primary/10',
    },
    {
      icon: CalendarCheck,
      title: lang === 'ar' ? 'حجز فوري' : 'Instant Booking',
      desc: lang === 'ar'
        ? 'احجز موعدك في ثوانٍ. تأكيد فوري مع رقم مرجعي.'
        : 'Book your appointment in seconds. Instant confirmation with a booking reference.',
      color: 'text-primary-light',
      bgColor: 'bg-primary-light/10',
    },
    {
      icon: Clock,
      title: lang === 'ar' ? 'متاح 24/7' : 'Available 24/7',
      desc: lang === 'ar'
        ? 'احجز في أي وقت من أي مكان. إلغاء مرن مع سياسة استرداد واضحة.'
        : 'Book anytime from anywhere. Flexible cancellation with a clear refund policy.',
      color: 'text-success',
      bgColor: 'bg-success/10',
    },
  ];

  return (
    <div>
      {/* ── Hero with rotating gallery ─────────────────────── */}
      <section className="relative overflow-hidden bg-primary">
        <div className="absolute inset-0">
          <img
            src={heroImages[0].url}
            alt={heroImages[0].alt}
            className="h-full w-full object-cover opacity-15"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-primary-900/95 via-primary-800/90 to-primary-700/85" />
        </div>

        {/* Floating decorative blobs */}
        <div className="absolute -top-24 -right-24 h-96 w-96 rounded-full bg-primary-light/10 blur-3xl animate-float" />
        <div className="absolute -bottom-32 -left-24 h-96 w-96 rounded-full bg-success/10 blur-3xl animate-float-delayed" />

        <div className="container-wide relative px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            {/* Left: Text + Search */}
            <div className="animate-slide-right">
              <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm text-primary-light-200 backdrop-blur-sm animate-fade-in">
                <span className="flex h-2 w-2 rounded-full bg-success-400 animate-pulse-glow" />
                {lang === 'ar' ? 'منصة صحية موثوقة في الإمارات' : 'Trusted healthcare platform in the UAE'}
              </div>

              <h1 className="text-4xl font-bold leading-tight text-white sm:text-5xl lg:text-6xl">
                {t('hero.title')}
              </h1>
              <p className="mt-6 max-w-xl text-lg leading-relaxed text-primary-light-100">
                {t('hero.subtitle')}
              </p>

              <form
                onSubmit={handleSearch}
                className="mt-10 flex max-w-xl items-center gap-2 rounded-2xl bg-white p-2 shadow-2xl transition-transform hover:scale-[1.02]"
              >
                <Search className="ms-3 h-5 w-5 shrink-0 text-gray-400" />
                <input
                  type="text"
                  value={searchValue}
                  onChange={(e) => setSearchValue(e.target.value)}
                  placeholder={t('hero.searchPlaceholder')}
                  className="flex-1 border-0 bg-transparent px-2 py-3 text-sm text-text-main placeholder:text-gray-400 focus:outline-none focus:ring-0"
                />
                <button type="submit" className="btn-accent shrink-0">
                  {t('hero.search')}
                </button>
              </form>

              {/* Quick stats */}
              <div className="mt-8 flex flex-wrap gap-6 text-white">
                {[
                  { icon: Shield, label: lang === 'ar' ? 'موثق من DHA' : 'DHA Verified' },
                  { icon: CalendarCheck, label: lang === 'ar' ? 'حجز فوري' : 'Instant Booking' },
                  { icon: Clock, label: lang === 'ar' ? 'متاح 24/7' : '24/7 Available' },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex items-center gap-2 text-sm text-primary-light-100">
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: Rotating gallery */}
            <div className="hidden lg:block">
              <div className="relative h-[440px] animate-slide-up">
                <div className="absolute inset-0 rounded-3xl shadow-2xl ring-1 ring-white/20">
                  <HeroGallery images={heroImages} interval={4500} />
                </div>
                {/* Floating badge */}
                <div className="absolute -bottom-5 -left-5 animate-float rounded-2xl bg-white p-4 shadow-xl dark:bg-background-dark-card">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-success/10">
                      <TrendingUp className="h-5 w-5 text-success" />
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-text-main dark:text-text-dark">
                        <AnimatedCounter value={98} suffix="%" />
                      </p>
                      <p className="text-xs text-text-muted dark:text-text-dark-muted">
                        {lang === 'ar' ? 'رضا المرضى' : 'Patient Satisfaction'}
                      </p>
                    </div>
                  </div>
                </div>
                {/* Floating badge 2 */}
                <div className="absolute -top-4 -right-4 animate-float-delayed rounded-2xl bg-white p-4 shadow-xl dark:bg-background-dark-card">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-light/10">
                      <Sparkles className="h-5 w-5 text-primary-light" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-text-main dark:text-text-dark">
                        {lang === 'ar' ? 'عيادات معتمدة' : 'Accredited Clinics'}
                      </p>
                      <p className="text-xs text-text-muted dark:text-text-dark-muted">
                        {lang === 'ar' ? 'في جميع الإمارات' : 'Across all Emirates'}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Stats bar */}
        <div ref={statsRef} className="relative border-t border-white/10 bg-black/20 backdrop-blur-sm">
          <div className="container-wide grid grid-cols-2 gap-4 px-4 py-6 sm:px-6 md:grid-cols-4 lg:px-8">
            {statItems.map((stat, i) => {
              const Icon = stat.icon;
              return (
                <div key={i} className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 transition-transform hover:scale-110">
                    <Icon className={`h-5 w-5 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-white">
                      {statsVisible && <AnimatedCounter value={stat.value} suffix={stat.suffix} />}
                    </p>
                    <p className="text-xs text-primary-light-200">{stat.label}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Core services carousel ─────────────────────────── */}
      <section className="section-padding">
        <div className="container-wide">
          <Reveal className="text-center">
            <h2 className="text-2xl font-bold text-text-main dark:text-text-dark sm:text-3xl">
              {lang === 'ar' ? 'خدماتنا الصحية المتكاملة' : 'Complete Healthcare Services'}
            </h2>
            <p className="mt-2 text-text-muted dark:text-text-dark-muted">
              {lang === 'ar'
                ? 'نربط المرضى والأطباء والعيادات والصيدليات في منصة واحدة'
                : 'Connecting patients, doctors, clinics, and pharmacies in one platform'}
            </p>
          </Reveal>

          <Reveal animation="up" delay={1} className="mt-10">
            <ServicesCarousel items={serviceItems} lang={lang} />
          </Reveal>
        </div>
      </section>

      {/* ── Specialties grid ───────────────────────────────── */}
      <section className="section-padding bg-background dark:bg-background-dark">
        <div className="container-wide">
          <Reveal className="text-center">
            <h2 className="text-2xl font-bold text-text-main dark:text-text-dark sm:text-3xl">
              {t('specialties.title')}
            </h2>
            <p className="mt-2 text-text-muted dark:text-text-dark-muted">{t('specialties.subtitle')}</p>
          </Reveal>

          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {specialties.map((spec, i) => {
              const Icon = spec.icon;
              return (
                <Reveal key={spec.name} animation="scale" delay={(i + 1) as 1 | 2 | 3 | 4 | 5 | 6}>
                  <button
                    onClick={() => navigate(`/doctors?specialty=${encodeURIComponent(spec.name)}`)}
                    className="card group flex w-full flex-col items-center gap-3 p-6 transition-all hover:-translate-y-1 hover:border-primary-light/30 hover:shadow-lg"
                  >
                    <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-light/10 transition-all duration-300 group-hover:scale-110 group-hover:bg-primary-light">
                      <Icon className="h-7 w-7 text-primary-light transition-colors group-hover:text-white" />
                    </div>
                    <span className="text-sm font-medium text-text-main dark:text-text-dark">
                      {lang === 'ar' ? spec.nameAr : spec.name}
                    </span>
                  </button>
                </Reveal>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── Top doctors ────────────────────────────────────── */}
      <section className="section-padding bg-gray-50 dark:bg-background-dark-card/30">
        <div className="container-wide">
          <Reveal className="flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold text-text-main dark:text-text-dark sm:text-3xl">
                {t('topDoctors.title')}
              </h2>
              <p className="mt-2 text-text-muted dark:text-text-dark-muted">{t('topDoctors.subtitle')}</p>
            </div>
            <button
              onClick={() => navigate('/doctors')}
              className="hidden items-center gap-1 text-sm font-medium text-primary-light transition-all hover:gap-2 hover:text-primary dark:text-primary-light sm:inline-flex"
            >
              {t('topDoctors.viewAll')}
              <ArrowRight className="h-4 w-4 rtl:rotate-180" />
            </button>
          </Reveal>

          {loading ? (
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="animate-pulse rounded-2xl border border-gray-100 bg-white p-5 dark:border-gray-800 dark:bg-background-dark-card">
                  <div className="flex gap-4">
                    <div className="h-14 w-14 rounded-full bg-gray-200 dark:bg-gray-700" />
                    <div className="flex-1 space-y-2">
                      <div className="h-4 w-3/4 rounded bg-gray-200 dark:bg-gray-700" />
                      <div className="h-3 w-1/2 rounded bg-gray-100 dark:bg-gray-800" />
                    </div>
                  </div>
                  <div className="mt-4 h-10 rounded bg-gray-50 dark:bg-gray-800" />
                </div>
              ))}
            </div>
          ) : (
            <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {doctors.map((doctor, i) => (
                <Reveal key={doctor.id} animation="up" delay={(i + 1) as 1 | 2 | 3 | 4 | 5 | 6}>
                  <DoctorCard doctor={doctor} />
                </Reveal>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ── Trust/compliance with photo strip ──────────────── */}
      <section className="section-padding">
        <div className="container-wide">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-2">
            {/* Left: Trust items */}
            <div>
              <Reveal>
                <h2 className="text-2xl font-bold text-text-main dark:text-text-dark sm:text-3xl">
                  {lang === 'ar' ? 'لماذا تختار الإمارة للصحة؟' : 'Why Choose Emara Health?'}
                </h2>
                <p className="mt-2 text-text-muted dark:text-text-dark-muted">
                  {lang === 'ar'
                    ? 'نحن نلتزم بأعلى معايير الرعاية الصحية والامتثال التنظيمي'
                    : 'We are committed to the highest standards of healthcare and regulatory compliance'}
                </p>
              </Reveal>

              <div className="mt-8 space-y-6">
                {trustItems.map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <Reveal key={i} animation="left" delay={(i + 1) as 1 | 2 | 3}>
                      <div className="flex items-start gap-4">
                        <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${item.bgColor} transition-transform hover:scale-110`}>
                          <Icon className={`h-6 w-6 ${item.color}`} />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-text-main dark:text-text-dark">{item.title}</h3>
                          <p className="mt-1 text-sm leading-relaxed text-text-muted dark:text-text-dark-muted">{item.desc}</p>
                        </div>
                      </div>
                    </Reveal>
                  );
                })}
              </div>
            </div>

            {/* Right: Photo collage */}
            <Reveal animation="right" delay={2}>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="overflow-hidden rounded-2xl shadow-md transition-transform hover:scale-[1.02]">
                    <img
                      src="https://images.pexels.com/photos/8460234/pexels-photo-8460234.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="Modern clinic room"
                      className="h-48 w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="overflow-hidden rounded-2xl shadow-md transition-transform hover:scale-[1.02]">
                    <img
                      src="https://images.pexels.com/photos/5888160/pexels-photo-5888160.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="Doctor smiling"
                      className="h-64 w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                </div>
                <div className="space-y-4 pt-8">
                  <div className="overflow-hidden rounded-2xl shadow-md transition-transform hover:scale-[1.02]">
                    <img
                      src="https://images.pexels.com/photos/19963167/pexels-photo-19963167.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="Female doctor portrait"
                      className="h-64 w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <div className="overflow-hidden rounded-2xl shadow-md transition-transform hover:scale-[1.02]">
                    <img
                      src="https://images.pexels.com/photos/9742853/pexels-photo-9742853.jpeg?auto=compress&cs=tinysrgb&w=600"
                      alt="Medications"
                      className="h-48 w-full object-cover"
                      loading="lazy"
                    />
                  </div>
                </div>
              </div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ── Testimonials ───────────────────────────────────── */}
      <section className="section-padding bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-900 via-primary-800 to-primary-700 animate-gradient" />
        <div className="absolute -top-20 -right-20 h-80 w-80 rounded-full bg-primary-light/10 blur-3xl" />

        <div className="container-wide relative">
          <Reveal className="text-center">
            <h2 className="text-2xl font-bold text-white sm:text-3xl">
              {lang === 'ar' ? 'ماذا يقول مرضانا' : 'What Our Patients Say'}
            </h2>
            <p className="mt-2 text-primary-light-200">
              {lang === 'ar' ? 'قصص حقيقية من مرضى وأطباء يستخدمون المنصة' : 'Real stories from patients and doctors using our platform'}
            </p>
          </Reveal>

          <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
            {testimonials.map((testimonial, i) => (
              <Reveal key={i} animation="up" delay={(i + 1) as 1 | 2 | 3}>
                <div className="rounded-2xl bg-white/10 p-6 backdrop-blur-sm transition-all hover:bg-white/15">
                  <div className="flex gap-1">
                    {[...Array(testimonial.rating)].map((_, j) => (
                      <Star key={j} className="h-4 w-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <p className="mt-4 text-sm leading-relaxed text-primary-light-100" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                    "{lang === 'ar' ? testimonial.textAr : testimonial.text}"
                  </p>
                  <div className="mt-5 flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 text-sm font-bold text-white">
                      {testimonial.name.charAt(0)}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-white">{testimonial.name}</p>
                      <p className="text-xs text-primary-light-200">
                        {lang === 'ar' ? testimonial.roleAr : testimonial.role}
                      </p>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ────────────────────────────────────────────── */}
      <section className="section-padding">
        <div className="container-wide">
          <Reveal animation="scale">
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-light to-primary p-10 text-center shadow-xl sm:p-16">
              <div className="absolute -top-12 -right-12 h-48 w-48 rounded-full bg-white/10 animate-float" />
              <div className="absolute -bottom-12 -left-12 h-48 w-48 rounded-full bg-white/10 animate-float-delayed" />

              <div className="relative">
                <h2 className="text-3xl font-bold text-white sm:text-4xl">
                  {lang === 'ar' ? 'ابدأ رحلتك الصحية اليوم' : 'Start Your Health Journey Today'}
                </h2>
                <p className="mx-auto mt-4 max-w-2xl text-lg text-primary-light-100">
                  {lang === 'ar'
                    ? 'انضم إلى آلاف المرضى الذين يثقون بمنصة الإمارة للصحة'
                    : 'Join thousands of patients who trust Emara Health Platform'}
                </p>
                <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
                  <button
                    onClick={() => navigate('/doctors')}
                    className="inline-flex items-center gap-2 rounded-xl bg-white px-8 py-3.5 text-sm font-semibold text-primary shadow-lg transition-all hover:scale-105 hover:shadow-xl"
                  >
                    {t('hero.bookNow')}
                    <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                  </button>
                  <button
                    onClick={() => navigate('/register')}
                    className="inline-flex items-center gap-2 rounded-xl border-2 border-white/40 bg-white/10 px-8 py-3.5 text-sm font-semibold text-white backdrop-blur-sm transition-all hover:bg-white/20"
                  >
                    {t('nav.register')}
                  </button>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
