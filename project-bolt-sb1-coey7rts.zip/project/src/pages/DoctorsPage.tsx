import { useEffect, useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, Search, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import type { Doctor } from '../lib/types';
import DoctorCard from '../components/DoctorCard';

type SortOption = 'rating' | 'feeLow' | 'feeHigh' | 'experience';

export default function DoctorsPage() {
  const { t, lang } = useI18n();
  const [searchParams, setSearchParams] = useSearchParams();
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') ?? '');
  const [specialty, setSpecialty] = useState(searchParams.get('specialty') ?? '');
  const [city, setCity] = useState('');
  const [gender, setGender] = useState('');
  const [language, setLanguage] = useState('');
  const [maxFee, setMaxFee] = useState(600);
  const [sortBy, setSortBy] = useState<SortOption>('rating');

  const specialties = useMemo(
    () => [...new Set(doctors.map((d) => d.specialty))].sort(),
    [doctors],
  );
  const cities = useMemo(
    () => [...new Set(doctors.map((d) => d.city).filter(Boolean))].sort() as string[],
    [doctors],
  );
  const languages = useMemo(
    () => [...new Set(doctors.flatMap((d) => d.languages))].sort(),
    [doctors],
  );

  useEffect(() => {
    const fetchDoctors = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('doctors')
        .select('*, clinic:clinics(*)')
        .order('rating', { ascending: false });

      if (error) {
        console.error('Error fetching doctors:', error);
      } else {
        setDoctors(data as Doctor[]);
      }
      setLoading(false);
    };
    fetchDoctors();
  }, []);

  useEffect(() => {
    const spec = searchParams.get('specialty');
    const q = searchParams.get('q');
    if (spec) setSpecialty(spec);
    if (q) setSearchQuery(q);
  }, [searchParams]);

  const filteredDoctors = useMemo(() => {
    let result = doctors.filter((d) => {
      if (specialty && d.specialty !== specialty) return false;
      if (city && d.city !== city) return false;
      if (gender && d.gender !== gender) return false;
      if (language && !d.languages.includes(language)) return false;
      if (d.consultation_fee > maxFee) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matches =
          d.full_name.toLowerCase().includes(q) ||
          d.specialty.toLowerCase().includes(q) ||
          (d.city?.toLowerCase().includes(q) ?? false);
        if (!matches) return false;
      }

      return true;
    });

    result = [...result].sort((a, b) => {
      switch (sortBy) {
        case 'feeLow':
          return a.consultation_fee - b.consultation_fee;
        case 'feeHigh':
          return b.consultation_fee - a.consultation_fee;
        case 'experience':
          return b.years_experience - a.years_experience;
        default:
          return b.rating - a.rating;
      }
    });

    return result;
  }, [doctors, specialty, city, gender, language, maxFee, searchQuery, sortBy]);

  const updateFilter = (key: string, value: string) => {
    if (key === 'specialty') setSpecialty(value);
    if (key === 'city') setCity(value);
    if (key === 'gender') setGender(value);
    if (key === 'language') setLanguage(value);
  };

  const clearFilters = () => {
    setSpecialty('');
    setCity('');
    setGender('');
    setLanguage('');
    setMaxFee(600);
    setSearchQuery('');
    setSearchParams({});
  };

  const hasActiveFilters = specialty || city || gender || language || searchQuery;

  const FilterContent = () => (
    <div className="space-y-5">
      <div>
        <label className="mb-2 block text-sm font-medium text-text-main dark:text-text-dark">{t('search.filterSpecialty')}</label>
        <select
          value={specialty}
          onChange={(e) => updateFilter('specialty', e.target.value)}
          className="input-field"
        >
          <option value="">{t('search.allSpecialties')}</option>
          {specialties.map((s) => (
            <option key={s} value={s}>
              {lang === 'ar' ? doctors.find((d) => d.specialty === s)?.specialty_ar ?? s : s}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium text-text-main dark:text-text-dark">{t('search.filterCity')}</label>
        <select value={city} onChange={(e) => updateFilter('city', e.target.value)} className="input-field">
          <option value="">{t('search.allCities')}</option>
          {cities.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium text-text-main dark:text-text-dark">{t('search.filterGender')}</label>
        <select value={gender} onChange={(e) => updateFilter('gender', e.target.value)} className="input-field">
          <option value="">{t('search.allGenders')}</option>
          <option value="male">{t('gender.male')}</option>
          <option value="female">{t('gender.female')}</option>
        </select>
      </div>

      <div>
        <label className="mb-2 block text-sm font-medium text-text-main dark:text-text-dark">{t('search.filterLanguage')}</label>
        <select
          value={language}
          onChange={(e) => updateFilter('language', e.target.value)}
          className="input-field"
        >
          <option value="">{t('search.allLanguages')}</option>
          {languages.map((l) => (
            <option key={l} value={l}>
              {l}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="mb-2 flex items-center justify-between text-sm font-medium text-text-main dark:text-text-dark">
          <span>{t('search.filterFee')}</span>
          <span className="font-semibold text-primary dark:text-primary-light">AED {maxFee}</span>
        </label>
        <input
          type="range"
          min={100}
          max={600}
          step={50}
          value={maxFee}
          onChange={(e) => setMaxFee(Number(e.target.value))}
          className="w-full accent-primary"
        />
      </div>

      {hasActiveFilters && (
        <button
          onClick={clearFilters}
          className="flex items-center gap-1 text-sm font-medium text-text-muted dark:text-text-dark-muted hover:text-text-main dark:hover:text-text-dark"
        >
          <X className="h-4 w-4" />
          {lang === 'ar' ? 'مسح الفلاتر' : 'Clear filters'}
        </button>
      )}
    </div>
  );

  return (
    <div className="section-padding bg-background dark:bg-background-dark">
      <div className="container-wide">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-main dark:text-text-dark">{t('search.title')}</h1>
          <p className="mt-2 text-text-muted dark:text-text-dark-muted">
            {loading ? (
              t('common.loading')
            ) : (
              <span>
                <span className="font-semibold text-primary dark:text-primary-light">{filteredDoctors.length}</span>{' '}
                {t('search.results')}
              </span>
            )}
          </p>
        </div>

        {/* Search bar */}
        <div className="mb-6 flex gap-3">
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('hero.searchPlaceholder')}
              className="input-field ps-10"
            />
          </div>
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="btn-secondary lg:hidden"
          >
            <SlidersHorizontal className="h-4 w-4" />
            {lang === 'ar' ? 'فلاتر' : 'Filters'}
          </button>
        </div>

        <div className="flex gap-8">
          {/* Desktop sidebar filters */}
          <aside className="hidden w-64 shrink-0 lg:block">
            <div className="card sticky top-24 p-5">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-text-main dark:text-text-dark">
                <SlidersHorizontal className="h-4 w-4" />
                {lang === 'ar' ? 'الفلاتر' : 'Filters'}
              </h2>
              <FilterContent />
            </div>
          </aside>

          {/* Mobile filter drawer */}
          {filtersOpen && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div className="absolute inset-0 bg-black/40" onClick={() => setFiltersOpen(false)} />
              <div className="absolute end-0 top-0 h-full w-80 max-w-[85%] overflow-y-auto bg-white dark:bg-background-dark-card p-5 shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <h2 className="text-sm font-semibold text-text-main dark:text-text-dark">{lang === 'ar' ? 'الفلاتر' : 'Filters'}</h2>
                  <button onClick={() => setFiltersOpen(false)} className="rounded-lg p-1 hover:bg-gray-100 dark:hover:bg-background-dark-elevated">
                    <X className="h-5 w-5 text-text-muted dark:text-text-dark-muted" />
                  </button>
                </div>
                <FilterContent />
                <button
                  onClick={() => setFiltersOpen(false)}
                  className="btn-primary mt-6 w-full"
                >
                  {lang === 'ar' ? 'عرض النتائج' : 'Show Results'} ({filteredDoctors.length})
                </button>
              </div>
            </div>
          )}

          {/* Results */}
          <div className="min-w-0 flex-1">
            <div className="mb-4 flex items-center justify-between">
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-background-dark-card px-3 py-2 text-sm text-text-main dark:text-text-dark focus:outline-none focus:ring-2 focus:ring-primary-light/30"
              >
                <option value="rating">{t('search.sortRating')}</option>
                <option value="feeLow">{t('search.sortFeeLow')}</option>
                <option value="feeHigh">{t('search.sortFeeHigh')}</option>
                <option value="experience">{t('search.sortExperience')}</option>
              </select>
            </div>

            {loading ? (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse rounded-2xl border border-gray-100 dark:border-gray-800 bg-white dark:bg-background-dark-card p-5">
                    <div className="flex gap-4">
                      <div className="h-14 w-14 rounded-full bg-gray-200 dark:bg-gray-700" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 w-3/4 rounded bg-gray-200 dark:bg-gray-700" />
                        <div className="h-3 w-1/2 rounded bg-gray-100 dark:bg-gray-800" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredDoctors.length === 0 ? (
              <div className="card flex flex-col items-center justify-center p-12 text-center">
                <Search className="h-12 w-12 text-text-muted dark:text-text-dark-muted" />
                <p className="mt-4 text-text-muted dark:text-text-dark-muted">{t('search.noResults')}</p>
                <button onClick={clearFilters} className="btn-secondary mt-4">
                  {lang === 'ar' ? 'مسح الفلاتر' : 'Clear filters'}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
                {filteredDoctors.map((doctor) => (
                  <DoctorCard key={doctor.id} doctor={doctor} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
