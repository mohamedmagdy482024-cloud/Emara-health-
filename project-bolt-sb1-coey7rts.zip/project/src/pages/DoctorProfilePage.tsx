import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  BadgeCheck, Star, MapPin, Globe, Clock, Calendar,
  ArrowLeft, ArrowRight, CreditCard, CalendarCheck,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import type { Doctor, Appointment } from '../lib/types';
import {
  formatAED, formatDate, formatTime, getDayKey,
  getNextDays, generateTimeSlots, isSlotInPast,
} from '../lib/utils';
import DoctorAvatar from '../components/DoctorAvatar';

const dayOrder = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const dayLabels: Record<string, { en: string; ar: string }> = {
  sun: { en: 'Sunday', ar: 'الأحد' },
  mon: { en: 'Monday', ar: 'الإثنين' },
  tue: { en: 'Tuesday', ar: 'الثلاثاء' },
  wed: { en: 'Wednesday', ar: 'الأربعاء' },
  thu: { en: 'Thursday', ar: 'الخميس' },
  fri: { en: 'Friday', ar: 'الجمعة' },
  sat: { en: 'Saturday', ar: 'السبت' },
};

export default function DoctorProfilePage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, lang } = useI18n();
  const { session } = useAuth();

  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [bookedSlots, setBookedSlots] = useState<string[]>([]);
  const [bookingStep, setBookingStep] = useState<'select' | 'review' | 'confirmed'>('select');
  const [bookingRef, setBookingRef] = useState<string>('');
  const [bookingError, setBookingError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const nextDays = getNextDays(14);

  useEffect(() => {
    const fetchDoctor = async () => {
      if (!id) return;
      const { data, error } = await supabase
        .from('doctors')
        .select('*, clinic:clinics(*)')
        .eq('id', id)
        .maybeSingle();

      if (error || !data) {
        setLoading(false);
        return;
      }
      setDoctor(data as Doctor);
      setLoading(false);
    };
    fetchDoctor();
  }, [id]);

  useEffect(() => {
    if (!selectedDay || !id) return;
    const fetchBookedSlots = async () => {
      const dateStr = selectedDay.toISOString().split('T')[0];
      const { data } = await supabase
        .from('appointments')
        .select('start_time')
        .eq('doctor_id', id)
        .eq('appointment_date', dateStr)
        .neq('status', 'cancelled');

      setBookedSlots(data?.map((a) => a.start_time) ?? []);
    };
    fetchBookedSlots();
  }, [selectedDay, id]);

  if (loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-text-muted dark:text-text-dark-muted">{t('common.loading')}</p>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
        <p className="text-text-muted dark:text-text-dark-muted">Doctor not found</p>
        <Link to="/doctors" className="btn-primary">{t('nav.doctors')}</Link>
      </div>
    );
  }

  const dayKey = selectedDay ? getDayKey(selectedDay) : '';
  const workingToday = doctor.working_hours[dayKey];
  const availableSlots = workingToday
    ? generateTimeSlots(
        workingToday.split('-')[0],
        workingToday.split('-')[1],
        30,
      ).filter((slot) => {
        if (!selectedDay) return false;
        if (isSlotInPast(selectedDay, slot)) return false;
        if (bookedSlots.includes(slot)) return false;
        return true;
      })
    : [];

  const handleConfirmBooking = async () => {
    if (!session) {
      navigate('/signin');
      return;
    }
    if (!selectedDay || !selectedTime || !doctor) return;

    setSubmitting(true);
    setBookingError(null);

    const dateStr = selectedDay.toISOString().split('T')[0];

    const { data, error } = await supabase
      .from('appointments')
      .insert({
        patient_id: session.user.id,
        doctor_id: doctor.id,
        clinic_id: doctor.clinic_id,
        appointment_date: dateStr,
        start_time: selectedTime,
        fee: doctor.consultation_fee,
        status: 'pending_payment',
      })
      .select()
      .single();

    if (error) {
      setBookingError(t('common.error'));
      setSubmitting(false);
      return;
    }

    const appointment = data as Appointment;
    setBookingRef(appointment.booking_ref);
    setBookingStep('confirmed');
    setSubmitting(false);
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= Math.round(rating)
                ? 'fill-amber-400 text-amber-400'
                : 'fill-gray-200 text-gray-200'
            }`}
          />
        ))}
        <span className="ms-1 text-sm font-medium text-text-main dark:text-text-dark">{rating.toFixed(1)}</span>
      </div>
    );
  };

  return (
    <div className="section-padding bg-background dark:bg-background-dark">
      <div className="container-wide">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 inline-flex items-center gap-1 text-sm text-text-muted dark:text-text-dark-muted hover:text-text-main dark:hover:text-text-dark"
        >
          <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
          {lang === 'ar' ? 'رجوع' : 'Back'}
        </button>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Doctor info */}
          <div className="lg:col-span-2">
            <div className="card p-6 sm:p-8">
              <div className="flex flex-col gap-6 sm:flex-row sm:items-start">
                <DoctorAvatar name={doctor.full_name} size="lg" photoUrl={doctor.photo_url} />
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h1 className="text-2xl font-bold text-text-main dark:text-text-dark" dir="auto">
                      {doctor.full_name}
                    </h1>
                    {doctor.dha_verified && (
                      <span className="badge bg-primary-light/10 text-primary dark:text-primary-light">
                        <BadgeCheck className="h-3.5 w-3.5" />
                        {t('doctor.dhaVerified')}
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-lg text-primary dark:text-primary-light">
                    {lang === 'ar' && doctor.specialty_ar ? doctor.specialty_ar : doctor.specialty}
                  </p>

                  <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-2">
                    {renderStars(doctor.rating)}
                    <span className="text-sm text-text-muted dark:text-text-dark-muted">
                      {doctor.years_experience} {t('doctor.experience')}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-text-muted dark:text-text-dark-muted">
                    {doctor.city && (
                      <span className="flex items-center gap-1.5">
                        <MapPin className="h-4 w-4 text-text-muted dark:text-text-dark-muted" />
                        {doctor.city}
                      </span>
                    )}
                    {doctor.languages.length > 0 && (
                      <span className="flex items-center gap-1.5">
                        <Globe className="h-4 w-4 text-text-muted dark:text-text-dark-muted" />
                        {doctor.languages.join(', ')}
                      </span>
                    )}
                    {doctor.dha_license && (
                      <span className="flex items-center gap-1.5 text-text-muted dark:text-text-dark-muted">
                        <BadgeCheck className="h-4 w-4 text-text-muted dark:text-text-dark-muted" />
                        DHA: {doctor.dha_license}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {doctor.bio && (
                <div className="mt-6 border-t border-gray-50 dark:border-gray-800 pt-6">
                  <h2 className="text-sm font-semibold uppercase tracking-wider text-text-muted dark:text-text-dark-muted">
                    {lang === 'ar' ? 'نبذة' : 'About'}
                  </h2>
                  <p className="mt-2 leading-relaxed text-text-main dark:text-text-dark" dir="auto">
                    {doctor.bio}
                  </p>
                </div>
              )}

              {/* Working hours */}
              <div className="mt-6 border-t border-gray-50 dark:border-gray-800 pt-6">
                <h2 className="flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-text-muted dark:text-text-dark-muted">
                  <Clock className="h-4 w-4" />
                  {t('doctor.workingHours')}
                </h2>
                <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {dayOrder.map((day) => {
                    const hours = doctor.working_hours[day];
                    const label = lang === 'ar' ? dayLabels[day].ar : dayLabels[day].en;
                    return (
                      <div
                        key={day}
                        className={`rounded-lg px-3 py-2 text-sm ${
                          hours
                            ? 'bg-primary-light/10 text-primary dark:text-primary-light'
                            : 'bg-gray-50 dark:bg-background-dark-card text-text-muted dark:text-text-dark-muted'
                        }`}
                      >
                        <p className="font-medium">{label}</p>
                        <p className="mt-0.5 text-xs">
                          {hours ? hours : (lang === 'ar' ? 'عطلة' : 'Closed')}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Booking sidebar */}
          <div className="lg:col-span-1">
            <div className="card sticky top-24 overflow-hidden">
              {/* Fee header */}
              <div className="bg-primary p-5 text-white">
                <p className="text-sm text-primary-light-100">{t('doctor.consultationFee')}</p>
                <p className="text-3xl font-bold">{formatAED(doctor.consultation_fee)}</p>
              </div>

              {bookingStep === 'confirmed' ? (
                <div className="p-6 text-center">
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-success/20">
                    <CalendarCheck className="h-8 w-8 text-success" />
                  </div>
                  <h3 className="mt-4 text-xl font-bold text-text-main dark:text-text-dark">{t('booking.confirmed')}</h3>
                  <p className="mt-2 text-sm text-text-muted dark:text-text-dark-muted">{t('booking.ref')}</p>
                  <p className="mt-1 text-lg font-mono font-bold text-primary dark:text-primary-light">{bookingRef}</p>

                  <div className="mt-6 space-y-2 rounded-xl bg-gray-50 dark:bg-background-dark-card p-4 text-start text-sm">
                    <div className="flex justify-between">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.doctor')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark" dir="auto">{doctor.full_name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.date')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark">{selectedDay && formatDate(selectedDay.toISOString(), lang)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.time')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark">{selectedTime && formatTime(selectedTime)}</span>
                    </div>
                  </div>

                  <p className="mt-4 rounded-lg bg-warning/10 px-3 py-2 text-xs text-warning">
                    {t('booking.paymentNote')}
                  </p>

                  <div className="mt-6 space-y-2">
                    <button onClick={() => navigate('/dashboard')} className="btn-primary w-full">
                      {t('booking.goDashboard')}
                    </button>
                    <button
                      onClick={() => {
                        setBookingStep('select');
                        setSelectedDay(null);
                        setSelectedTime(null);
                      }}
                      className="btn-secondary w-full"
                    >
                      {t('booking.bookAnother')}
                    </button>
                  </div>
                </div>
              ) : bookingStep === 'review' ? (
                <div className="p-5">
                  <h3 className="text-lg font-bold text-text-main dark:text-text-dark">{t('booking.review')}</h3>
                  <div className="mt-4 space-y-3 text-sm">
                    <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-3">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.doctor')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark" dir="auto">{doctor.full_name}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-3">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.date')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark">{selectedDay && formatDate(selectedDay.toISOString(), lang)}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-3">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.time')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark">{selectedTime && formatTime(selectedTime)}</span>
                    </div>
                    <div className="flex justify-between border-b border-gray-50 dark:border-gray-800 pb-3">
                      <span className="text-text-muted dark:text-text-dark-muted">{t('booking.fee')}</span>
                      <span className="font-medium text-text-main dark:text-text-dark">{formatAED(doctor.consultation_fee)}</span>
                    </div>
                    <div className="flex justify-between pt-1">
                      <span className="font-semibold text-text-main dark:text-text-dark">{t('booking.total')}</span>
                      <span className="text-lg font-bold text-primary dark:text-primary-light">{formatAED(doctor.consultation_fee)}</span>
                    </div>
                  </div>

                  <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
                    <CreditCard className="mt-0.5 h-4 w-4 shrink-0" />
                    <p>{t('booking.paymentNote')}</p>
                  </div>

                  {bookingError && (
                    <p className="mt-3 text-sm text-error">{bookingError}</p>
                  )}

                  <div className="mt-5 flex gap-2">
                    <button onClick={() => setBookingStep('select')} className="btn-secondary flex-1">
                      {t('booking.back')}
                    </button>
                    <button
                      onClick={handleConfirmBooking}
                      disabled={submitting}
                      className="btn-primary flex-1"
                    >
                      {submitting ? t('common.loading') : t('booking.confirm')}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-5">
                  {!session && (
                    <div className="mb-4 rounded-xl bg-warning/10 p-3 text-sm text-warning">
                      {t('booking.needSignIn')}
                    </div>
                  )}

                  <h3 className="flex items-center gap-2 text-lg font-bold text-text-main dark:text-text-dark">
                    <Calendar className="h-5 w-5 text-primary dark:text-primary-light" />
                    {t('booking.step1')}
                  </h3>

                  {/* Day picker */}
                  <div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-7">
                    {nextDays.map((day) => {
                      const dk = getDayKey(day);
                      const isWorking = !!doctor.working_hours[dk];
                      const isSelected = selectedDay?.toDateString() === day.toDateString();
                      const isToday = day.toDateString() === new Date().toDateString();

                      return (
                        <button
                          key={day.toISOString()}
                          disabled={!isWorking}
                          onClick={() => {
                            setSelectedDay(day);
                            setSelectedTime(null);
                          }}
                          className={`flex flex-col items-center rounded-xl border p-2 text-center transition-all ${
                            isSelected
                              ? 'border-primary-600 bg-primary text-white'
                              : isWorking
                                ? 'border-gray-200 dark:border-gray-700 bg-white dark:bg-background-dark-card text-text-main dark:text-text-dark hover:border-primary-300'
                                : 'cursor-not-allowed border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-background-dark-card text-text-muted dark:text-text-dark-muted'
                          }`}
                        >
                          <span className="text-xs font-medium">
                            {lang === 'ar'
                              ? dayLabels[dk].ar.substring(0, 3)
                              : day.toLocaleDateString('en', { weekday: 'short' })}
                          </span>
                          <span className="text-lg font-bold">{day.getDate()}</span>
                          {isToday && (
                            <span className={`text-[10px] ${isSelected ? 'text-primary-light-100' : 'text-primary dark:text-primary-light'}`}>
                              {lang === 'ar' ? 'اليوم' : 'Today'}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Time slots */}
                  {selectedDay && (
                    <div className="mt-6 animate-fade-in">
                      <h3 className="flex items-center gap-2 text-lg font-bold text-text-main dark:text-text-dark">
                        <Clock className="h-5 w-5 text-primary dark:text-primary-light" />
                        {t('booking.step2')}
                      </h3>

                      {availableSlots.length === 0 ? (
                        <p className="mt-3 rounded-xl bg-gray-50 dark:bg-background-dark-card p-4 text-center text-sm text-text-muted dark:text-text-dark-muted">
                          {t('booking.noSlots')}
                        </p>
                      ) : (
                        <div className="mt-3 grid grid-cols-3 gap-2">
                          {availableSlots.map((slot) => (
                            <button
                              key={slot}
                              onClick={() => setSelectedTime(slot)}
                              className={`rounded-lg border py-2 text-sm font-medium transition-all ${
                                selectedTime === slot
                                  ? 'border-primary-600 bg-primary text-white'
                                  : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-background-dark-card text-text-main dark:text-text-dark hover:border-primary-300'
                              }`}
                            >
                              {formatTime(slot)}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {selectedTime && (
                    <button
                      onClick={() => setBookingStep('review')}
                      className="btn-primary mt-6 w-full animate-slide-up"
                    >
                      {t('booking.next')}
                      <ArrowRight className="h-4 w-4 rtl:rotate-180" />
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
