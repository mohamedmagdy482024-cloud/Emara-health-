import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, AlertCircle } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import Logo from '../components/Logo';

export default function SignInPage() {
  const { t } = useI18n();
  const { signIn } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const normalizedEmail = email.trim().includes('@')
      ? email.trim()
      : email.trim();

    const { error: signInError } = await signIn(normalizedEmail, password);

    if (signInError) {
      setError(t('auth.invalidCreds'));
      setLoading(false);
      return;
    }

    navigate('/dashboard');
  };

  const fillDemo = (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('Password123!');
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary-light/10 via-background to-primary/10 dark:from-primary/20 dark:via-background-dark dark:to-primary/20 px-4 py-12">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center">
          <Link to="/" className="inline-flex items-center gap-2">
            <Logo />
          </Link>
        </div>

        <div className="card p-8">
          <h1 className="text-2xl font-bold text-text-main dark:text-text-dark">{t('auth.signIn')}</h1>
          <p className="mt-2 text-sm text-text-muted dark:text-text-dark-muted">{t('auth.signInSubtitle')}</p>

          {error && (
            <div className="mt-4 flex items-center gap-2 rounded-xl bg-error/10 px-4 py-3 text-sm text-error">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                {t('auth.emailOrPhone')}
              </label>
              <div className="relative">
                <Mail className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                <input
                  type="text"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="input-field ps-10"
                  placeholder="patient@example.com"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-text-main dark:text-text-dark">
                {t('auth.password')}
              </label>
              <div className="relative">
                <Lock className="pointer-events-none absolute start-3 top-1/2 h-5 w-5 -translate-y-1/2 text-text-muted dark:text-text-dark-muted" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="input-field ps-10"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? t('common.loading') : t('auth.signInBtn')}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-text-muted dark:text-text-dark-muted">
            {t('auth.noAccount')}{' '}
            <Link to="/register" className="font-medium text-primary dark:text-primary-light hover:text-primary-600 dark:hover:text-primary-light">
              {t('auth.registerHere')}
            </Link>
          </p>
        </div>

        {/* Demo accounts */}
        <div className="card mt-4 p-4">
          <p className="text-xs font-medium text-text-muted dark:text-text-dark-muted">{t('auth.demoAccounts')}</p>
          <div className="mt-2 space-y-1.5">
            <button
              onClick={() => fillDemo('patient@example.com')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs text-text-muted dark:text-text-dark-muted transition-colors hover:bg-primary-light/10"
            >
              <span>Patient</span>
              <span className="font-mono text-text-muted dark:text-text-dark-muted">patient@example.com</span>
            </button>
            <button
              onClick={() => fillDemo('dr.ahmed.alrashidi@emarahealth.ae')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs text-text-muted dark:text-text-dark-muted transition-colors hover:bg-primary-light/10"
            >
              <span>Doctor</span>
              <span className="font-mono text-text-muted dark:text-text-dark-muted">dr.ahmed.alrashidi@emarahealth.ae</span>
            </button>
            <button
              onClick={() => fillDemo('admin@emarahealth.ae')}
              className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-xs text-text-muted dark:text-text-dark-muted transition-colors hover:bg-primary-light/10"
            >
              <span>Admin</span>
              <span className="font-mono text-text-muted dark:text-text-dark-muted">admin@emarahealth.ae</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
