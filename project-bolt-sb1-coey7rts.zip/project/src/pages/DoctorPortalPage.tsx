import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Clock, CheckCircle2, XCircle, Calendar, Users,
  AlertCircle, Save,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';
import type { Appointment, AppointmentStatus, Doctor } from '../lib/types';
import { formatTime } from '../lib/utils';

const statusConfig: Record<AppointmentStatus, { color: string; label: string; labelAr: string }> = {
  confirmed: { color: 'bg-success/20 text-success', label: 'Confirmed', labelAr: 'مؤكد' },
  pending_payment: { color: 'bg-warning/20 text-warning', label: 'Pending Payment', labelAr: 'بانتظار الدفع' },
  completed: { color: 'bg-blue-100 text-blue-700', label: 'Completed', labelAr: 'مكتمل' },
  cancelled: { color: 'bg-gray-100 dark:bg-background-dark-elevated text-text-muted dark:text-text-dark-muted', label: 'Cancelled', labelAr: 'ملغي' },
  no_show: { color: 'bg-error/20 text-error', label: 'No Show', labelAr: 'لم يحضر' },
};

const dayOrder = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
const dayLabels: Record<string, { en: string; ar: string }> = {
  sun: { en: 'Sun', ar: 'أحد' },
  mon: { en: 'Mon', ar: 'إثن' },
  tue: { en: 'Tue', ar: 'ثلا' },
  wed: { en: 'Wed', ar: 'أرب' },
  thu: { en: 'Thu', ar: 'خمي' },
  fri: { en: 'Fri', ar: 'جمع' },
  sat: { en: 'Sat', ar: 'سبت' },
};

export default function DoctorPortalPage() {
  const { t, lang } = useI18n();
  const { session, profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'schedule'>('overview');
  const [workingHours, setWorkingHours] = useState<Record<string, string>>({});
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [scheduleSaved, setScheduleSaved] = useState(false);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  useEffect(() => {
    if (authLoading) return;
    if (!session) {
      navigate('/signin');
      return;
    }
    if (profile && profile.role !== 'doctor') {
      navigate(profile.role === 'admin' ? '/admin' : '/dashboard');
      return;
    }

    const fetchDoctorData = async () => {
      if (!session) return;
      const { data: doctorData } = await supabase
        .from('doctors')
        .select('*')
        .eq('user_id', session.user.id)
        .maybeSingle();

      if (!doctorData) {
        setLoading(false);
        return;
      }

      const doc = doctorData as Doctor;
      setDoctor(doc);
      setWorkingHours(doc.working_hours || {});

      const today = new Date().toISOString().split('T')[0];
      const { data: apptData } = await supabase
        .from('appointments')
        .select('*, patient:profiles(*)')
        .eq('doctor_id', doc.id)
        .eq('appointment_date', today)
        .order('start_time', { ascending: true });

      if (apptData) {
        setAppointments(apptData as Appointment[]);
      }
      setLoading(false);
    };
    fetchDoctorData();
  }, [session, profile, authLoading, navigate]);

  const handleUpdateStatus = async (apptId: string, status: AppointmentStatus) => {
    setUpdatingId(apptId);
    const { error } = await supabase
      .from('appointments')
      .update({ status })
      .eq('id', apptId);

    if (!error) {
      setAppointments((prev) => prev.map((a) => (a.id === apptId ? { ...a, status } : a)));
    }
    setUpdatingId(null);
  };

  const handleSaveSchedule = async () => {
    if (!doctor) return;
    setSavingSchedule(true);
    const { error } = await supabase
      .from('doctors')
      .update({ working_hours: workingHours })
      .eq('id', doctor.id);

    if (!error) {
      setScheduleSaved(true);
      setTimeout(() => setScheduleSaved(false), 3000);
    }
    setSavingSchedule(false);
  };

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-text-muted dark:text-text-dark-muted">{t('common.loading')}</p>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="flex min-h-[60vh] flex-col items-center justify-center gap-4">
        <p className="text-text-muted dark:text-text-dark-muted">No doctor profile linked to your account.</p>
      </div>
    );
  }

  const completedCount = appointments.filter((a) => a.status === 'completed').length;
  const upcomingCount = appointments.filter(
    (a) => a.status === 'confirmed' || a.status === 'pending_payment',
  ).length;

  const counters = [
    { icon: Users, label: t('doctorPortal.todayPatients'), value: appointments.length, color: 'bg-primary' },
    { icon: CheckCircle2, label: t('doctorPortal.completed'), value: completedCount, color: 'bg-success' },
    { icon: Clock, label: t('doctorPortal.upcoming'), value: upcomingCount, color: 'bg-amber-500' },
  ];

  return (
    <div className="section-padding bg-background dark:bg-background-dark">
      <div className="container-wide">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-main dark:text-text-dark">{t('doctorPortal.title')}</h1>
          <p className="mt-1 text-text-muted dark:text-text-dark-muted">{t('doctorPortal.subtitle')}</p>
        </div>

        {/* Tabs */}
        <div className="mb-6 flex gap-1 rounded-xl bg-gray-100 dark:bg-background-dark-elevated p-1 w-fit">
          <button
            onClick={() => setActiveTab('overview')}
            className={`rounded-lg px-6 py-2.5 text-sm font-medium transition-all ${
              activeTab === 'overview' ? 'bg-white dark:bg-background-dark-card text-primary dark:text-primary-light shadow-sm' : 'text-text-muted dark:text-text-dark-muted'
            }`}
          >
            {t('doctorPortal.title')}
          </button>
          <button
            onClick={() => setActiveTab('schedule')}
            className={`rounded-lg px-6 py-2.5 text-sm font-medium transition-all ${
              activeTab === 'schedule' ? 'bg-white dark:bg-background-dark-card text-primary dark:text-primary-light shadow-sm' : 'text-text-muted dark:text-text-dark-muted'
            }`}
          >
            {t('doctorPortal.schedule')}
          </button>
        </div>

        {activeTab === 'overview' ? (
          <>
            {/* Counters */}
            <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
              {counters.map((counter, i) => {
                const Icon = counter.icon;
                return (
                  <div key={i} className="card p-5">
                    <div className="flex items-center gap-4">
                      <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${counter.color}`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <p className="text-3xl font-bold text-text-main dark:text-text-dark">{counter.value}</p>
                        <p className="text-sm text-text-muted dark:text-text-dark-muted">{counter.label}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Appointments table */}
            <div className="card overflow-hidden">
              {appointments.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-12 text-center">
                  <Calendar className="h-12 w-12 text-text-muted dark:text-text-dark-muted" />
                  <p className="mt-4 text-text-muted dark:text-text-dark-muted">{t('doctorPortal.noAppointments')}</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-100 dark:border-gray-800 bg-gray-50 dark:bg-background-dark-card text-xs font-semibold uppercase tracking-wider text-text-muted dark:text-text-dark-muted">
                        <th className="px-5 py-3 text-start">{t('doctorPortal.time')}</th>
                        <th className="px-5 py-3 text-start">{t('doctorPortal.patient')}</th>
                        <th className="px-5 py-3 text-start">{t('doctorPortal.status')}</th>
                        <th className="px-5 py-3 text-end">{t('doctorPortal.actions')}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 dark:divide-gray-800">
                      {appointments.map((appt) => {
                        const status = statusConfig[appt.status];
                        const canAct = appt.status === 'confirmed' || appt.status === 'pending_payment';
                        return (
                          <tr key={appt.id} className="transition-colors hover:bg-gray-50/50 dark:hover:bg-background-dark-card/50">
                            <td className="px-5 py-4">
                              <p className="font-semibold text-text-main dark:text-text-dark">{formatTime(appt.start_time)}</p>
                            </td>
                            <td className="px-5 py-4">
                              <p className="font-medium text-text-main dark:text-text-dark" dir="auto">
                                {appt.patient?.full_name ?? 'Unknown'}
                              </p>
                              <p className="text-xs text-text-muted dark:text-text-dark-muted">{appt.booking_ref}</p>
                            </td>
                            <td className="px-5 py-4">
                              <span className={`badge ${status.color}`}>
                                {lang === 'ar' ? status.labelAr : status.label}
                              </span>
                            </td>
                            <td className="px-5 py-4">
                              {canAct ? (
                                <div className="flex justify-end gap-2">
                                  <button
                                    onClick={() => handleUpdateStatus(appt.id, 'completed')}
                                    disabled={updatingId === appt.id}
                                    className="rounded-lg border border-success/30 px-3 py-1.5 text-xs font-medium text-success transition-colors hover:bg-success/10 disabled:opacity-50"
                                  >
                                    {t('doctorPortal.markComplete')}
                                  </button>
                                  <button
                                    onClick={() => handleUpdateStatus(appt.id, 'no_show')}
                                    disabled={updatingId === appt.id}
                                    className="rounded-lg border border-error/30 px-3 py-1.5 text-xs font-medium text-error transition-colors hover:bg-error/10 disabled:opacity-50"
                                  >
                                    {t('doctorPortal.markNoShow')}
                                  </button>
                                </div>
                              ) : (
                                <span className="text-xs text-text-muted dark:text-text-dark-muted">—</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        ) : (
          /* Schedule editor */
          <div className="card p-6">
            <h2 className="text-lg font-bold text-text-main dark:text-text-dark">{t('doctorPortal.workingHours')}</h2>
            <p className="mt-1 text-sm text-text-muted dark:text-text-dark-muted">
              {lang === 'ar'
                ? 'قم بتعديل ساعات عملك. التغييرات فورية للمرضى.'
                : 'Edit your working hours. Changes immediately affect what patients can book.'}
            </p>

            <div className="mt-6 space-y-3">
              {dayOrder.map((day) => {
                const hours = workingHours[day] || '';
                const isOff = !hours;
                return (
                  <div key={day} className="flex items-center gap-4">
                    <div className="w-20 text-sm font-medium text-text-main dark:text-text-dark">
                      {lang === 'ar' ? dayLabels[day].ar : dayLabels[day].en}
                    </div>
                    <div className="flex flex-1 items-center gap-2">
                      <input
                        type="time"
                        value={hours.split('-')[0] || '09:00'}
                        disabled={isOff}
                        onChange={(e) => {
                          const end = hours.split('-')[1] || '17:00';
                          setWorkingHours({ ...workingHours, [day]: `${e.target.value}-${end}` });
                        }}
                        className="input-field flex-1 disabled:bg-gray-50 dark:disabled:bg-background-dark-card disabled:text-text-muted dark:disabled:text-text-dark-muted"
                      />
                      <span className="text-text-muted dark:text-text-dark-muted">—</span>
                      <input
                        type="time"
                        value={hours.split('-')[1] || '17:00'}
                        disabled={isOff}
                        onChange={(e) => {
                          const start = hours.split('-')[0] || '09:00';
                          setWorkingHours({ ...workingHours, [day]: `${start}-${e.target.value}` });
                        }}
                        className="input-field flex-1 disabled:bg-gray-50 dark:disabled:bg-background-dark-card disabled:text-text-muted dark:disabled:text-text-dark-muted"
                      />
                    </div>
                    <button
                      onClick={() => {
                        const newHours = { ...workingHours };
                        if (isOff) {
                          newHours[day] = '09:00-17:00';
                        } else {
                          delete newHours[day];
                        }
                        setWorkingHours(newHours);
                      }}
                      className={`rounded-lg px-3 py-2 text-xs font-medium transition-colors ${
                        isOff
                          ? 'bg-primary-light/10 text-primary dark:text-primary-light hover:bg-primary-light/20'
                          : 'bg-gray-100 dark:bg-background-dark-elevated text-text-muted dark:text-text-dark-muted hover:bg-gray-200 dark:hover:bg-gray-700'
                      }`}
                    >
                      {isOff
                        ? (lang === 'ar' ? 'إضافة' : 'Add')
                        : (lang === 'ar' ? 'إزالة' : 'Remove')}
                    </button>
                  </div>
                );
              })}
            </div>

            {scheduleSaved && (
              <div className="mt-4 flex items-center gap-2 rounded-xl bg-success/10 px-4 py-3 text-sm text-success">
                <CheckCircle2 className="h-4 w-4" />
                {t('doctorPortal.scheduleSaved')}
              </div>
            )}

            <button
              onClick={handleSaveSchedule}
              disabled={savingSchedule}
              className="btn-primary mt-6"
            >
              <Save className="h-4 w-4" />
              {savingSchedule ? t('common.loading') : t('doctorPortal.saveSchedule')}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
