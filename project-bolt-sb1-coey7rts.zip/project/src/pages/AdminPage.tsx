import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users, Stethoscope, Building2, Calendar,
  AlertCircle, Clock, Shield, FileText, Bell,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useI18n } from '../lib/i18n';
import { useAuth } from '../lib/auth';

interface ModuleStatus {
  name: string;
  nameAr: string;
  status: 'built' | 'in_progress' | 'not_started';
  statusLabel: string;
  statusLabelAr: string;
  notes: string;
  notesAr: string;
}

export default function AdminPage() {
  const { t, lang } = useI18n();
  const { session, profile, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  const [stats, setStats] = useState({ doctors: 0, patients: 0, clinics: 0, appointments: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!session) {
      navigate('/signin');
      return;
    }
    if (profile && profile.role !== 'admin') {
      navigate(profile.role === 'doctor' ? '/doctor' : '/dashboard');
      return;
    }

    const fetchStats = async () => {
      const [
        { count: doctorCount },
        { count: patientCount },
        { count: clinicCount },
        { count: apptCount },
      ] = await Promise.all([
        supabase.from('doctors').select('*', { count: 'exact', head: true }),
        supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'patient'),
        supabase.from('clinics').select('*', { count: 'exact', head: true }),
        supabase.from('appointments').select('*', { count: 'exact', head: true }),
      ]);

      setStats({
        doctors: doctorCount ?? 0,
        patients: patientCount ?? 0,
        clinics: clinicCount ?? 0,
        appointments: apptCount ?? 0,
      });
      setLoading(false);
    };
    fetchStats();
  }, [session, profile, authLoading, navigate]);

  if (authLoading || loading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <p className="text-text-muted dark:text-text-dark-muted">{t('common.loading')}</p>
      </div>
    );
  }

  const statCards = [
    { icon: Stethoscope, label: t('admin.totalDoctors'), value: stats.doctors, color: 'bg-primary' },
    { icon: Users, label: t('admin.totalPatients'), value: stats.patients, color: 'bg-secondary-600' },
    { icon: Building2, label: t('admin.totalClinics'), value: stats.clinics, color: 'bg-accent-600' },
    { icon: Calendar, label: t('admin.totalAppointments'), value: stats.appointments, color: 'bg-success' },
  ];

  const modules: ModuleStatus[] = [
    {
      name: 'Patient Booking',
      nameAr: 'حجز المواعيد',
      status: 'built',
      statusLabel: 'Built',
      statusLabelAr: 'مبني',
      notes: 'Full booking flow with real appointment creation and slot filtering.',
      notesAr: 'مسار حجز كامل مع إنشاء مواعيد حقيقية وفلترة المواعيد.',
    },
    {
      name: 'Doctor Portal',
      nameAr: 'بوابة الطبيب',
      status: 'built',
      statusLabel: 'Built',
      statusLabelAr: 'مبني',
      notes: 'Today overview, mark complete/no-show, working hours editor.',
      notesAr: 'نظرة عامة على اليوم، إكمال/عدم حضور، محرر ساعات العمل.',
    },
    {
      name: 'Arabic / RTL',
      nameAr: 'العربية / RTL',
      status: 'built',
      statusLabel: 'Built',
      statusLabelAr: 'مبني',
      notes: 'Full public site translation with RTL layout.',
      notesAr: 'ترجمة كاملة للموقع العام مع تخطيط RTL.',
    },
    {
      name: 'Card Payment',
      nameAr: 'الدفع بالبطاقة',
      status: 'in_progress',
      statusLabel: 'Not Configured',
      statusLabelAr: 'غير مُفعّل',
      notes: 'Appointments held as pending payment. Requires Stripe keys.',
      notesAr: 'تُحجز المواعيد كدفعة معلّقة. تتطلب مفاتيح Stripe.',
    },
    {
      name: 'Notifications',
      nameAr: 'الإشعارات',
      status: 'not_started',
      statusLabel: 'Not Started',
      statusLabelAr: 'لم يبدأ',
      notes: 'No WhatsApp or email notifications sent yet.',
      notesAr: 'لم يتم إرسال إشعارات WhatsApp أو بريد إلكتروني بعد.',
    },
    {
      name: 'Medical Records',
      nameAr: 'السجلات الطبية',
      status: 'not_started',
      statusLabel: 'Not Started',
      statusLabelAr: 'لم يبدأ',
      notes: 'Requires encrypted storage, access controls, and audit logging before shipping.',
      notesAr: 'يتطلب تخزين مشفّر وضوابط وصول وسجل تدقيق قبل الإطلاق.',
    },
    {
      name: 'Audit Log',
      nameAr: 'سجل التدقيق',
      status: 'not_started',
      statusLabel: 'Not Started',
      statusLabelAr: 'لم يبدأ',
      notes: 'Required for DHA/NABIDH compliance before real patient data.',
      notesAr: 'مطلوب للامتثال لـ DHA/NABIDH قبل بيانات المرضى الحقيقية.',
    },
    {
      name: 'Privacy / Terms',
      nameAr: 'الخصوصية / الشروط',
      status: 'in_progress',
      statusLabel: 'Draft',
      statusLabelAr: 'مسودة',
      notes: 'Pending legal review before publishing.',
      notesAr: 'بانتظار المراجعة القانونية قبل النشر.',
    },
  ];

  const statusColors: Record<string, string> = {
    built: 'bg-success/20 text-success',
    in_progress: 'bg-warning/20 text-warning',
    not_started: 'bg-gray-100 dark:bg-background-dark-elevated text-text-muted dark:text-text-dark-muted',
  };

  const moduleIcons: Record<string, typeof Calendar> = {
    'Patient Booking': Calendar,
    'Doctor Portal': Stethoscope,
    'Arabic / RTL': FileText,
    'Card Payment': AlertCircle,
    Notifications: Bell,
    'Medical Records': FileText,
    'Audit Log': Shield,
    'Privacy / Terms': FileText,
  };

  return (
    <div className="section-padding bg-background dark:bg-background-dark">
      <div className="container-wide">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-text-main dark:text-text-dark">{t('admin.title')}</h1>
          <p className="mt-1 text-text-muted dark:text-text-dark-muted">{t('admin.subtitle')}</p>
        </div>

        {/* Stats */}
        <div className="mb-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {statCards.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="card p-5">
                <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${stat.color}`}>
                  <Icon className="h-5 w-5 text-white" />
                </div>
                <p className="mt-4 text-3xl font-bold text-text-main dark:text-text-dark">{stat.value}</p>
                <p className="text-sm text-text-muted dark:text-text-dark-muted">{stat.label}</p>
              </div>
            );
          })}
        </div>

        {/* Modules */}
        <div>
          <h2 className="mb-4 text-xl font-bold text-text-main dark:text-text-dark">{t('admin.modules')}</h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            {modules.map((mod) => {
              const Icon = moduleIcons[mod.name] ?? FileText;
              return (
                <div key={mod.name} className="card p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gray-100 dark:bg-background-dark-elevated">
                        <Icon className="h-5 w-5 text-text-muted dark:text-text-dark-muted" />
                      </div>
                      <div>
                        <p className="font-semibold text-text-main dark:text-text-dark">
                          {lang === 'ar' ? mod.nameAr : mod.name}
                        </p>
                        <p className="mt-1 text-sm text-text-muted dark:text-text-dark-muted" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
                          {lang === 'ar' ? mod.notesAr : mod.notes}
                        </p>
                      </div>
                    </div>
                    <span className={`badge shrink-0 ${statusColors[mod.status]}`}>
                      {lang === 'ar' ? mod.statusLabelAr : mod.statusLabel}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Security note */}
        <div className="mt-8 rounded-2xl border border-warning/30 bg-warning/10 p-5">
          <div className="flex items-start gap-3">
            <Shield className="mt-0.5 h-5 w-5 shrink-0 text-warning" />
            <div>
              <p className="font-semibold text-warning">
                {lang === 'ar' ? 'متطلبات أمنية قبل الإطلاق' : 'Security requirements before launch'}
              </p>
              <p className="mt-1 text-sm text-warning">
                {lang === 'ar'
                  ? 'مطلوب: حماية المسارات حسب الدور، فحص ملكية الدفع، كتابة سجل التدقيق، وتحديد معدل الطلبات.'
                  : 'Required: role-based route guards, payment ownership checks, audit-log writes, and rate limiting.'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
