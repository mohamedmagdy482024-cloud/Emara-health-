/*
# Emara Health Platform — Core Schema

1. Purpose
   A UAE healthcare marketplace connecting patients, doctors, and clinics.
   This migration creates the four core tables that power the patient journey,
   doctor portal, and admin panel: profiles, clinics, doctors, and appointments.

2. New Tables
   - `profiles` — extends auth.users with role (patient/doctor/admin), full name, phone, city, gender, languages.
   - `clinics` — healthcare facilities across Dubai, Abu Dhabi, Sharjah with English + Arabic names.
   - `doctors` — doctor profiles linked to auth.users and clinics: specialty, DHA number, consultation fee, bio, weekly working hours, rating.
   - `appointments` — a booking row linking a patient to a doctor at a specific date/time, with status and booking reference.

3. Security (RLS)
   - `profiles`: owner-scoped CRUD — each authenticated user manages only their own profile row. A SELECT policy lets any authenticated user read profiles (needed for doctor/patient names).
   - `clinics`: public read (anon + authenticated), no writes from the client.
   - `doctors`: public read (anon + authenticated), updates scoped to the owning doctor.
   - `appointments`: patients can read/insert/cancel only their own; doctors can read and update status of appointments assigned to them. Admins can read all.

4. Notes
   - `user_id` columns default to `auth.uid()` so inserts that omit the owner still satisfy RLS.
   - Booking references generated as `EH-XXXXXX` via a default expression.
   - Working hours stored as JSONB keyed by day abbreviation.
*/

-- ── profiles ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'patient' CHECK (role IN ('patient','doctor','admin')),
  full_name text NOT NULL DEFAULT '',
  phone text,
  city text,
  gender text CHECK (gender IN ('male','female','other')),
  languages text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all_auth" ON profiles;
CREATE POLICY "profiles_select_all_auth" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ── clinics ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS clinics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  name_ar text NOT NULL DEFAULT '',
  city text NOT NULL,
  area text,
  address text,
  phone text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE clinics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "clinics_select_public" ON clinics;
CREATE POLICY "clinics_select_public" ON clinics FOR SELECT
  TO anon, authenticated USING (true);

-- ── doctors ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  full_name text NOT NULL,
  specialty text NOT NULL,
  specialty_ar text NOT NULL DEFAULT '',
  dha_license text,
  dha_verified boolean NOT NULL DEFAULT false,
  consultation_fee numeric(10,2) NOT NULL DEFAULT 0,
  bio text DEFAULT '',
  gender text CHECK (gender IN ('male','female','other')),
  languages text[] DEFAULT '{}',
  city text,
  clinic_id uuid REFERENCES clinics(id) ON DELETE SET NULL,
  working_hours jsonb NOT NULL DEFAULT '{}'::jsonb,
  rating numeric(2,1) DEFAULT 5.0,
  years_experience int DEFAULT 0,
  photo_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE doctors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "doctors_select_public" ON doctors;
CREATE POLICY "doctors_select_public" ON doctors FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "doctors_update_own" ON doctors;
CREATE POLICY "doctors_update_own" ON doctors FOR UPDATE
  TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- ── appointments ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_ref text NOT NULL DEFAULT ('EH-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 6))),
  patient_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  doctor_id uuid NOT NULL REFERENCES doctors(id) ON DELETE CASCADE,
  clinic_id uuid REFERENCES clinics(id) ON DELETE SET NULL,
  appointment_date date NOT NULL,
  start_time time NOT NULL,
  status text NOT NULL DEFAULT 'confirmed' CHECK (status IN ('confirmed','pending_payment','completed','cancelled','no_show')),
  fee numeric(10,2) NOT NULL DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "appt_select_own_patient" ON appointments;
CREATE POLICY "appt_select_own_patient" ON appointments FOR SELECT
  TO authenticated
  USING (
    patient_id = auth.uid()
    OR EXISTS (SELECT 1 FROM doctors d WHERE d.user_id = auth.uid() AND d.id = appointments.doctor_id)
    OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
  );

DROP POLICY IF EXISTS "appt_insert_own_patient" ON appointments;
CREATE POLICY "appt_insert_own_patient" ON appointments FOR INSERT
  TO authenticated
  WITH CHECK (patient_id = auth.uid());

DROP POLICY IF EXISTS "appt_update_own" ON appointments;
CREATE POLICY "appt_update_own" ON appointments FOR UPDATE
  TO authenticated
  USING (
    patient_id = auth.uid()
    OR EXISTS (SELECT 1 FROM doctors d WHERE d.user_id = auth.uid() AND d.id = appointments.doctor_id)
  )
  WITH CHECK (
    patient_id = auth.uid()
    OR EXISTS (SELECT 1 FROM doctors d WHERE d.user_id = auth.uid() AND d.id = appointments.doctor_id)
  );

DROP POLICY IF EXISTS "appt_delete_own_patient" ON appointments;
CREATE POLICY "appt_delete_own_patient" ON appointments FOR DELETE
  TO authenticated
  USING (patient_id = auth.uid());

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_doctors_specialty ON doctors(specialty);
CREATE INDEX IF NOT EXISTS idx_doctors_city ON doctors(city);
CREATE INDEX IF NOT EXISTS idx_appointments_patient ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_doctor ON appointments(doctor_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
